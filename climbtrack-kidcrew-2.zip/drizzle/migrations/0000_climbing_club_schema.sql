
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Instructors read profiles" ON public.profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "Users insert own profile" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "Users update own profile" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id);

CREATE TABLE public.groups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  weekday SMALLINT NOT NULL CHECK (weekday BETWEEN 1 AND 4),
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.groups TO authenticated;
GRANT ALL ON public.groups TO service_role;
ALTER TABLE public.groups ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Instructors read groups" ON public.groups FOR SELECT TO authenticated USING (true);
CREATE POLICY "Instructors manage groups" ON public.groups FOR ALL TO authenticated USING (true) WITH CHECK (true);

INSERT INTO public.groups (name, weekday, start_time, end_time) VALUES
  ('Malí horolezci', 1, '14:30', '16:00'),
  ('Skalní veverky', 1, '16:00', '17:30'),
  ('Pokročilí', 1, '17:30', '19:00'),
  ('Malí horolezci', 2, '14:30', '16:00'),
  ('Starteři', 2, '16:00', '17:30'),
  ('Pokročilí', 2, '17:30', '19:00'),
  ('Malí horolezci', 3, '14:30', '16:00'),
  ('Starteři', 3, '16:00', '17:30'),
  ('Pokročilí', 3, '17:30', '19:00'),
  ('Malí horolezci', 4, '14:30', '16:00'),
  ('Starteři', 4, '16:00', '17:30'),
  ('Připravená parta', 4, '17:30', '19:00');

CREATE TABLE public.children (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id UUID NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  birth_year SMALLINT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.children TO authenticated;
GRANT ALL ON public.children TO service_role;
ALTER TABLE public.children ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Instructors read children" ON public.children FOR SELECT TO authenticated USING (true);
CREATE POLICY "Instructors manage children" ON public.children FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.climbs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id UUID NOT NULL REFERENCES public.children(id) ON DELETE CASCADE,
  group_id UUID NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  logged_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  grade TEXT NOT NULL,
  route_name TEXT,
  route_color TEXT,
  style TEXT NOT NULL DEFAULT 'přelez' CHECK (style IN ('přelez', 'OS', 'flash')),
  note TEXT,
  climbed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.climbs TO authenticated;
GRANT ALL ON public.climbs TO service_role;
ALTER TABLE public.climbs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Instructors read climbs" ON public.climbs FOR SELECT TO authenticated USING (true);
CREATE POLICY "Instructors insert climbs" ON public.climbs FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Instructors update climbs" ON public.climbs FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Instructors delete climbs" ON public.climbs FOR DELETE TO authenticated USING (true);

CREATE INDEX idx_children_group ON public.children(group_id);
CREATE INDEX idx_climbs_child ON public.climbs(child_id);
CREATE INDEX idx_climbs_group ON public.climbs(group_id);
CREATE INDEX idx_climbs_climbed_at ON public.climbs(climbed_at DESC);
