CREATE TABLE public.routes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  color text NOT NULL,
  chain_number smallint NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (color, chain_number)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.routes TO authenticated;
GRANT ALL ON public.routes TO service_role;
ALTER TABLE public.routes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Instructors manage routes" ON public.routes FOR ALL TO authenticated USING (true) WITH CHECK (true);

ALTER TABLE public.climbs ADD COLUMN route_id uuid REFERENCES public.routes(id) ON DELETE SET NULL;
ALTER TABLE public.climbs ADD COLUMN chain_number smallint;
ALTER TABLE public.climbs ADD COLUMN falls smallint NOT NULL DEFAULT 0;
ALTER TABLE public.climbs ALTER COLUMN grade SET DEFAULT '';
ALTER TABLE public.climbs ALTER COLUMN style SET DEFAULT 'top rope';
COMMENT ON COLUMN public.climbs.grade IS 'DEPRECATED: routes identified by color + chain number';