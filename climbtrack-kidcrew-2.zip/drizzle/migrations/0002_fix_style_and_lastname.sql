ALTER TABLE public.climbs DROP CONSTRAINT IF EXISTS climbs_style_check;
ALTER TABLE public.climbs ADD CONSTRAINT climbs_style_check CHECK (style = ANY (ARRAY['top rope'::text, 'na prvním'::text, 'přelez'::text, 'OS'::text, 'flash'::text]));
ALTER TABLE public.children ALTER COLUMN last_name SET DEFAULT '';
COMMENT ON COLUMN public.children.last_name IS 'DEPRECATED: surnames no longer used';