CREATE TABLE public.lezik_challenges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT '',
  starts_on date NOT NULL DEFAULT current_date,
  ends_on date NOT NULL DEFAULT (current_date + 13),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.lezik_challenges TO authenticated;
GRANT ALL ON public.lezik_challenges TO service_role;
ALTER TABLE public.lezik_challenges ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Instructors manage lezik challenges" ON public.lezik_challenges FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.lezik_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  challenge_id uuid NOT NULL REFERENCES public.lezik_challenges(id) ON DELETE CASCADE,
  title text NOT NULL,
  reward smallint NOT NULL DEFAULT 1,
  position smallint NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.lezik_tasks TO authenticated;
GRANT ALL ON public.lezik_tasks TO service_role;
ALTER TABLE public.lezik_tasks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Instructors manage lezik tasks" ON public.lezik_tasks FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.lezik_completions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id uuid NOT NULL REFERENCES public.children(id) ON DELETE CASCADE,
  task_id uuid REFERENCES public.lezik_tasks(id) ON DELETE SET NULL,
  task_title text NOT NULL,
  reward smallint NOT NULL,
  completed_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (child_id, task_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.lezik_completions TO authenticated;
GRANT ALL ON public.lezik_completions TO service_role;
ALTER TABLE public.lezik_completions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Instructors manage lezik completions" ON public.lezik_completions FOR ALL TO authenticated USING (true) WITH CHECK (true);