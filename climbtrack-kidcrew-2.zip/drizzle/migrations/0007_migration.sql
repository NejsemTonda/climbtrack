DO $$ DECLARE t text; BEGIN
FOREACH t IN ARRAY ARRAY['groups','children','climbs','routes','lezik_challenges','lezik_tasks','lezik_completions'] LOOP
  EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON public.%I TO anon', t);
  EXECUTE format('CREATE POLICY "Public access" ON public.%I FOR ALL TO anon USING (true) WITH CHECK (true)', t);
END LOOP; END $$;