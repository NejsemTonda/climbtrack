# Roadmapa

## Hotovo
- Pády pryč, body 2/4 (Index)
- Soutěž Lezík: stránka Lezík (14denní výzva, 3 úkoly s vlastním počtem lezíků), odškrtávání na kartě dítěte, lezíky v seznamu dětí
- Přepínač soutěží Kružík / Lezík v horní liště (Lezík už není ve spodní liště)
- Výzvy Lezík: tlačítko „Upravit výzvu" (název, termín, úkoly i jejich hodnoty, přidání/odebrání úkolu); vyhlášení nové výzvy se ptá na potvrzení
- Vzhled: bílé pozadí stránky, bílé lišty (horní i spodní, oddělené tenkou linkou a měkkým stínem), syté barvy obsahu, jména dětí větší a tmavá
- Název aplikace přejmenován na HC4 (dřív Kružík); ikona HC4 má vlastní modrou (odlišenou od tyrkysového tlačítka „Zapsat cestu")
- Na kartě dítěte je tlačítko „Zapsat cestu" nad boxem se zápisem Lezíků
- Barvy: syté a výrazné (ne vybledlé), ale jména dětí větší a tmavá, aby vynikla nad barevnými prvky
- Gender: kluk modré kolečko, holka růžové; přepínač Kluk/Holka je při přidání i v „Upravit"
- Spodní lišta: Kroužky kaštanová, Děti korálová (vybráno z nabídky — klidné barvy, žádná se neopakuje); Cesty zůstávají zelené
- Pohlaví se pozná automaticky ze jména (při psaní jména se přepínač sám přepne; zůstává jako ruční oprava) — doplněno i u všech stávajících dětí
- Zápis cesty z karty dítěte má jen cesty (barva · řetěz), styl a poznámku — kolonka „Dítě" tam není, dítě je dané z karty
- Hlavní stránka: jen přepínač dne šipkami (cyklicky Po–Čt) a tři karty kroužků; karty mají malé kolečko se šipkou (28px) a titulek „Otevřít kroužek"
- Spodní lišta zmenšena na telefonu (23 px) i na počítači (44 px; dřív 66 px)
- Přepínač dnů na hlavní stránce: kolečka se šipkami zmenšená (48px → 36px, šipka 36px → 24px)
- Přihlášení zjednodušeno: jediné velké tlačítko „Pokračovat přes Google", žádný e-mail, heslo ani přepínač registrace; přihlášený uživatel se na /auth rovnou dostane do aplikace

## Otevřené
- (nic)

- Hotovo: odklikávání cest, mazání výzev Lezíku
