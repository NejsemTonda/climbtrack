import { useState } from "react";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import {
  childrenQuery,
  routesQuery,
  ROUTE_COLORS,
  STYLES,
  colorCls,
  STYLE_META,
  STYLE_POINTS,
} from "@/lib/queries";

export function AddClimbDialog({
  groupId,
  childId,
  onClose,
}: {
  groupId: string;
  childId?: string;
  onClose: () => void;
}) {
  const queryClient = useQueryClient();
  const { data: children } = useSuspenseQuery(childrenQuery(groupId));
  const { data: routes } = useSuspenseQuery(routesQuery());
  const [selectedChild, setSelectedChild] = useState(childId ?? "");
  const [routeId, setRouteId] = useState("");
  const [showNewRoute, setShowNewRoute] = useState(false);
  const [newColor, setNewColor] = useState("");
  const [newChain, setNewChain] = useState("");
  const [style, setStyle] = useState<(typeof STYLES)[number]>("top rope");
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);

  async function addRoute() {
    const n = Number(newChain);
    if (!newColor || !newChain || !Number.isInteger(n) || n < 1 || n > 999) {
      toast.error("Vyberte barvu a zadejte číslo řetězu");
      return;
    }
    const existing = routes.find((r) => r.color === newColor && r.chain_number === n);
    if (existing) {
      setRouteId(existing.id);
      setShowNewRoute(false);
      return;
    }
    const { data, error } = await supabase
      .from("routes")
      .insert({ color: newColor, chain_number: n })
      .select()
      .single();
    if (error || !data) {
      toast.error("Cestu se nepodařilo přidat");
      return;
    }
    await queryClient.invalidateQueries({ queryKey: ["routes"] });
    setRouteId(data.id);
    setNewColor("");
    setNewChain("");
    setShowNewRoute(false);
    toast.success("Cesta přidána do seznamu");
  }

  async function save() {
    if (!selectedChild) {
      toast.error("Vyberte dítě");
      return;
    }
    const route = routes.find((r) => r.id === routeId);
    if (!route) {
      toast.error("Vyberte cestu");
      return;
    }
    setSaving(true);
    const { data: prev } = await supabase
      .from("climbs")
      .select("style")
      .eq("child_id", selectedChild)
      .eq("route_color", route.color)
      .eq("chain_number", route.chain_number);
    const prevStyles = (prev ?? []).map((p) => p.style);
    if (prevStyles.includes(style)) {
      setSaving(false);
      toast.error(`Tuhle cestu už má zapsanou (${style})`);
      return;
    }
    if (style === "top rope" && prevStyles.includes("na prvním")) {
      setSaving(false);
      toast.error("Tuhle cestu už vylezl/a na prvním");
      return;
    }
    const {
      data: { user },
    } = await supabase.auth.getUser();
    const { error } = await supabase.from("climbs").insert({
      child_id: selectedChild,
      group_id: groupId,
      logged_by: user?.id ?? null,
      route_id: route.id,
      route_color: route.color,
      chain_number: route.chain_number,
      grade: "",
      style,
      note: note.trim().slice(0, 500) || null,
    });
    setSaving(false);
    if (error) {
      toast.error("Záznam se nepodařilo uložit");
      return;
    }
    toast.success("Cesta zapsána!");
    await queryClient.invalidateQueries();
    onClose();
  }

  const label = "block text-[11px] font-semibold uppercase tracking-wider text-muted-foreground";
  const stylePill = (s: string, active: boolean) =>
    `rounded-xl py-2.5 text-sm font-bold transition-colors ${
      active
        ? s === "na prvním"
          ? "bg-forest text-primary-foreground shadow-md shadow-forest/30"
          : "bg-cesty text-ink-foreground shadow-md shadow-cesty/30"
        : "bg-secondary text-secondary-foreground"
    }`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/30 p-4 backdrop-blur-sm sm:items-center"
      onClick={onClose}
    >
      <div
        className="glass-card max-h-[90vh] w-full max-w-md overflow-y-auto p-5"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="flex items-center gap-2 text-base font-bold">
          <span className="grid size-7 place-items-center rounded-xl bg-primary/12 text-[14px] text-primary">
            ⛰
          </span>
          Zapsat vylezenou cestu
        </h2>

        {!childId && (
          <>
            <label className={`mt-4 ${label}`}>Dítě</label>
            <select
              value={selectedChild}
              onChange={(e) => setSelectedChild(e.target.value)}
              className="mt-1.5 w-full rounded-xl border border-input bg-card px-3 py-2.5 text-sm outline-none focus:border-ring"
            >
              <option value="">— vyberte —</option>
              {children.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.first_name}
                </option>
              ))}
            </select>
          </>
        )}

        <div className={`${childId ? "mt-4" : "mt-3"} flex items-center justify-between`}>
          <label className={label}>Cesta (barva · řetěz)</label>
          <button
            type="button"
            onClick={() => setShowNewRoute(!showNewRoute)}
            className="text-xs font-semibold text-primary"
          >
            {showNewRoute ? "Zavřít" : "＋ Nová cesta"}
          </button>
        </div>

        {showNewRoute && (
          <div className="mt-1.5 rounded-xl border border-input bg-card/60 p-3">
            <div className="flex flex-wrap gap-2">
              {ROUTE_COLORS.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  title={c.id}
                  onClick={() => setNewColor(c.id)}
                  className={`size-7 rounded-full ${c.cls} ${
                    newColor === c.id ? "ring-2 ring-ring ring-offset-2" : ""
                  }`}
                />
              ))}
            </div>
            <div className="mt-2 flex gap-2">
              <input
                type="number"
                inputMode="numeric"
                min={1}
                max={999}
                value={newChain}
                onChange={(e) => setNewChain(e.target.value)}
                placeholder="Číslo řetězu"
                className="w-full rounded-xl border border-input bg-card px-3 py-2 text-sm outline-none focus:border-ring"
              />
              <button
                type="button"
                onClick={addRoute}
                className="shrink-0 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-foreground"
              >
                Přidat
              </button>
            </div>
            {newColor && <p className="mt-1.5 text-[11px] text-muted-foreground">Barva: {newColor}</p>}
          </div>
        )}

        <div className="mt-1.5 flex flex-wrap gap-1.5">
          {routes.length === 0 && !showNewRoute && (
            <p className="text-xs text-muted-foreground">Zatím žádné cesty — přidejte první.</p>
          )}
          {routes.map((r) => (
            <button
              key={r.id}
              type="button"
              title={`${r.color} · řetěz ${r.chain_number}`}
              onClick={() => setRouteId(r.id)}
              className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-bold transition-colors ${
                routeId === r.id
                  ? "bg-primary text-primary-foreground shadow-md shadow-primary/30"
                  : "bg-secondary text-secondary-foreground"
              }`}
            >
              <span className={`size-3 rounded-full ${colorCls(r.color)}`} />
              {r.chain_number}
            </button>
          ))}
        </div>

        <label className={`mt-3 ${label}`}>Styl</label>
        <div className="mt-1.5 grid grid-cols-2 gap-2">
          {STYLES.map((s) => (
            <button key={s} type="button" onClick={() => setStyle(s)} className={stylePill(s, style === s)}>
              {STYLE_META[s]?.label ?? s}
              <span className="ml-1 text-[11px] font-extrabold opacity-80">
                {STYLE_POINTS[s]} b
              </span>
            </button>
          ))}
        </div>

        <input
          type="text"
          value={note}
          maxLength={500}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Poznámka (nepovinné)"
          className="mt-3 w-full rounded-xl border border-input bg-card px-3 py-2.5 text-sm outline-none focus:border-ring"
        />

        <div className="mt-4 grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl border border-input bg-card py-2.5 text-sm font-semibold"
          >
            Zrušit
          </button>
          <button
            type="button"
            onClick={save}
            disabled={saving}
            className="rounded-xl bg-zapis py-2.5 text-sm font-semibold text-ink-foreground shadow-md shadow-zapis/30 disabled:opacity-60"
          >
            {saving ? "Ukládám…" : "Zapsat"}
          </button>
        </div>
      </div>
    </div>
  );
}
