import { Link, useRouterState } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { CalendarDays, Coins, Mountain, Route as RouteIcon, Users } from "lucide-react";

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const onLezik = pathname.startsWith("/lezik");

  const tab = (active: boolean, activeCls: string) =>
    `flex flex-1 items-center justify-center gap-1 rounded-md py-0.5 text-[10px] font-bold leading-tight transition-colors sm:flex-col sm:gap-0.5 sm:rounded-xl sm:py-0.5 sm:text-[11px] ${
      active ? activeCls : "text-ink-foreground/60"
    }`;

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col px-4 pb-6">
      <header className="sticky top-0 z-30 -mx-4 border-b border-border bg-ink text-ink-foreground shadow-sm">
        <div className="flex items-center justify-between gap-2 px-4 py-3">
          <div className="flex rounded-full bg-ink-foreground/10 p-1">
            <Link
              to="/"
              className={`flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-[14px] font-extrabold tracking-tight transition-colors ${
                !onLezik ? "bg-brand text-primary-foreground shadow" : "text-ink-foreground/70"
              }`}
            >
              <Mountain className="size-4" strokeWidth={2.5} />
              HC4
            </Link>
            <Link
              to="/lezik"
              className={`flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-[14px] font-extrabold tracking-tight transition-colors ${
                onLezik ? "bg-amber text-primary-foreground shadow" : "text-ink-foreground/70"
              }`}
            >
              <Coins className="size-4" strokeWidth={2.5} />
              Lezík
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">{children}</main>

      <nav className="sticky bottom-[max(0.375rem,env(safe-area-inset-bottom))] mt-5 flex gap-0.5 rounded-lg bg-ink p-0.5 shadow-md ring-1 ring-border sm:bottom-3 sm:gap-1 sm:rounded-2xl sm:p-0.5">
        <Link
          to="/"
          className={tab(pathname === "/" || pathname.startsWith("/skupina"), "bg-krouzky text-primary-foreground")}
        >
          <CalendarDays className="size-[15px] sm:size-5" />
          Kroužky
        </Link>
        <Link to="/deti" className={tab(pathname.startsWith("/deti"), "bg-deti text-primary-foreground")}>
          <Users className="size-[15px] sm:size-5" />
          Děti
        </Link>
        <Link to="/cesty" className={tab(pathname.startsWith("/cesty"), "bg-cesty text-ink-foreground")}>
          <RouteIcon className="size-[15px] sm:size-5" />
          Cesty
        </Link>
      </nav>
    </div>
  );
}
