import { levelMeta } from "@/lib/queries";

const LEVEL_CLS: Record<string, string> = {
  "začátečník": "bg-lvl-beginner",
  "mírně pokročilé": "bg-lvl-mid",
  master: "bg-lvl-master",
};

export function ChildAvatar({
  name,
  gender,
  level,
  size = "md",
}: {
  name: string;
  gender: string | null | undefined;
  level: string | null | undefined;
  size?: "md" | "lg";
}) {
  const box = size === "lg" ? "size-12 text-lg" : "size-8 text-[11px]";
  const bar = size === "lg" ? "h-12" : "h-8";
  return (
    <div className="flex shrink-0 items-center gap-1.5">
      <span
        aria-label={level ?? "začátečník"}
        className={`${bar} w-1.5 rounded-full ${LEVEL_CLS[level ?? "začátečník"] ?? LEVEL_CLS["začátečník"]}`}
      />
      <div
        className={`grid ${box} place-items-center rounded-full font-extrabold text-primary-foreground ${gender === "holka" ? "bg-girl" : "bg-boy"}`}
      >
        {name[0]}
      </div>
    </div>
  );
}

export function LevelChip({ level }: { level: string | null | undefined }) {
  const m = levelMeta(level);
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold ${m.chip}`}
    >
      <span className={`size-1.5 rounded-full ${m.dot}`} />
      {m.label}
    </span>
  );
}

export function GenderPicker({
  value,
  onChange,
}: {
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div className="grid grid-cols-2 gap-2">
      {(["kluk", "holka"] as const).map((g) => (
        <button
          key={g}
          type="button"
          onClick={() => onChange(g)}
          className={`rounded-xl py-2.5 text-sm font-semibold ${
            value === g
              ? `${g === "holka" ? "bg-girl" : "bg-boy"} text-primary-foreground`
              : "border border-input bg-card"
          }`}
        >
          {g === "kluk" ? "Kluk" : "Holka"}
        </button>
      ))}
    </div>
  );
}
