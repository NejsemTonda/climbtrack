import { useState } from "react";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { routesQuery, colorCls } from "@/lib/queries";

type Climb = { style: string | null; route_color: string | null; chain_number: number | null };

export function QuickClimbList({
  childId,
  groupId,
  climbs,
}: {
  childId: string;
  groupId: string;
  climbs: Climb[];
}) {
  const queryClient = useQueryClient();
  const { data: routes } = useSuspenseQuery(routesQuery());
  const [busy, setBusy] = useState<string | null>(null);

  const done = new Map<string, Set<string>>();
  for (const c of climbs) {
    if (!c.route_color || !c.chain_number) continue;
    const k = `${c.route_color}#${c.chain_number}`;
    if (!done.has(k)) done.set(k, new Set());
    done.get(k)!.add(c.style ?? "");
  }
  const rank = (k: string) => {
    const s = done.get(k);
    if (s?.has("na prvním")) return 2;
    if (s?.has("top rope")) return 1;
    return 0;
  };
  const sorted = [...routes].sort(
    (a, b) => rank(`${a.color}#${a.chain_number}`) - rank(`${b.color}#${b.chain_number}`),
  );

  async function log(route: (typeof routes)[number], style: "top rope" | "na prvním") {
    setBusy(`${route.id}:${style}`);
    const {
      data: { user },
    } = await supabase.auth.getUser();
    const { error } = await supabase.from("climbs").insert({
      child_id: childId,
      group_id: groupId,
      logged_by: user?.id ?? null,
      route_id: route.id,
      route_color: route.color,
      chain_number: route.chain_number,
      grade: "",
      style,
    });
    setBusy(null);
    if (error) {
      toast.error("Záznam se nepodařilo uložit");
      return;
    }
    toast.success(`${route.color} ${route.chain_number} · ${style === "na prvním" ? "Lead" : "Top Rope"} zapsáno`);
    await queryClient.invalidateQueries();
  }

  async function undo(route: (typeof routes)[number], style: "top rope" | "na prvním") {
    if (!confirm(`Zrušit zápis ${route.color} ${route.chain_number} · ${style === "na prvním" ? "Lead" : "Top Rope"}?`)) return;
    setBusy(`${route.id}:${style}`);
    const { error } = await supabase
      .from("climbs")
      .delete()
      .eq("child_id", childId)
      .eq("route_color", route.color)
      .eq("chain_number", route.chain_number)
      .eq("style", style);
    setBusy(null);
    if (error) {
      toast.error("Zápis se nepodařilo zrušit");
      return;
    }
    toast.success("Zápis zrušen");
    await queryClient.invalidateQueries();
  }

  const btn = (active: boolean, disabled: boolean) =>
    `rounded-lg px-3 py-2 text-[12px] font-bold transition-transform active:scale-95 ${
      active
        ? "bg-zapis text-ink-foreground"
        : disabled
          ? "bg-secondary/50 text-muted-foreground/50"
          : "border border-input bg-card text-foreground"
    }`;

  return (
    <div className="mt-3">
      <h2 className="mb-2 text-[15px] font-bold tracking-tight">Cesty</h2>
      {routes.length === 0 && (
        <p className="glass-card p-4 text-center text-sm text-muted-foreground">
          Zatím žádné cesty — přidejte je na stránce Cesty.
        </p>
      )}
      <div className="space-y-1.5">
        {sorted.map((r) => {
          const k = `${r.color}#${r.chain_number}`;
          const lvl = rank(k);
          return (
            <div
              key={r.id}
              className={`glass-chip flex items-center gap-2.5 px-3 py-2 ${lvl === 2 ? "opacity-60" : ""}`}
            >
              <span className={`size-4 shrink-0 rounded-full ${colorCls(r.color)}`} />
              <p className="flex-1 text-[14px] font-bold">
                {r.color} <span className="text-muted-foreground">· {r.chain_number}</span>
              </p>
              <button
                disabled={lvl === 2 || busy !== null}
                onClick={() => (lvl === 1 ? undo(r, "top rope") : log(r, "top rope"))}
                className={btn(lvl === 1, lvl >= 1)}
              >
                {lvl >= 1 ? "✓ " : ""}Top Rope
              </button>
              <button
                disabled={busy !== null}
                onClick={() => (lvl === 2 ? undo(r, "na prvním") : log(r, "na prvním"))}
                className={btn(lvl === 2, false)}
              >
                {lvl === 2 ? "✓ " : ""}Lead
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
