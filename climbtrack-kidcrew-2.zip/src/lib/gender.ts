// Rozpoznání pohlaví z českého křestního jména.
// Slouží k přednastavení přepínače Kluk/Holka — ten zůstává jako ruční oprava.

/** Běžná česká ženská jména (včetně obvyklých domáckých tvarů). */
export const FEMALE_NAMES: string[] = [
  "ada", "adela", "adéla", "adélie", "agáta", "alena", "alžběta", "amálie", "amelie", "ana",
  "anděla", "andrea", "aneta", "anežka", "anička", "anka", "anna", "barbora", "barča",
  "barunka", "beáta", "beta", "běta", "bianka", "blanka", "bohumila", "božena", "božka",
  "brunela", "cecilie", "cyriliena", "damiena", "daniela", "dara", "denisa", "deniska",
  "desislava", "dita", "dominika", "dorota", "draha", "drahuše", "dubravka", "edith", "edna",
  "eliška", "elen", "elena", "eleonora", "elisa", "emilie", "emily", "emma", "emílie", "erika",
  "estera", "eugenie", "eva", "evelína", "fanny", "filomena", "flóra", "františka", "gabriela",
  "gabina", "gertruda", "gita", "gréta", "hana", "hančka", "hanna", "heda", "helen", "helena",
  "henrieta", "hermina", "hilda", "ida", "ilona", "ingrid", "irena", "irina", "isabela",
  "iveta", "ivona", "izabela", "jarmila", "jasmína", "jehta", "jindra", "jindřiška", "jitka",
  "jitěnka", "johana", "josefina", "julie", "justýna", "karina", "karína", "karla", "karolína",
  "kateřina", "kačenka", "kazi", "kazimíra", "klementýna", "klára", "klaudie", "kristýna",
  "kristyna", "květa", "květoslava", "lada", "lara", "laura", "leona", "linda", "ludmila",
  "lucie", "lucinka", "luíza", "lída", "magdalena", "magdaléna", "marcela", "marie", "marta",
  "martina", "matylda", "melánie", "michaela", "mila", "milada", "milena", "miloslava",
  "miluše", "míša", "monika", "nadežda", "naděžda", "natálie", "nely", "nela", "nicola",
  "nikola", "nikol", "nina", "ofélie", "ofelie", "olena", "olžbeta", "patricie", "pavla",
  "penelopa", "petra", "petronela", "radana", "radmila", "radomíra", "rahela", "rebecca",
  "regina", "renata", "renáta", "richarda", "roberta", "rozálie", "růžena", "salome",
  "samuela", "sandra", "sára", "simona", "sofie", "sofia", "sona", "sonia", "sonka",
  "stanislava", "stela", "štěpánka", "tadeáška", "tamara", "tatiana", "tereza", "terezie",
  "terinka", "terezka", "tina", "tončka", "uliana", "ulrika", "valentina", "valérie", "vanda",
  "verika", "veronika", "verunka", "viktorie", "vilemína", "violeta", "viola", "vita", "vlasta",
  "vlastimila", "xenie", "zdeňka", "zdenka", "zdena", "zita", "zofie", "zuzana", "zuzanka",
  "žaneta", "žofie",
];

/** Běžná česká mužská jména. */
export const MALE_NAMES: string[] = [
  "abel", "adam", "adolf", "alexandr", "alexander", "aleš", "albert", "alois", "andršt",
  "andrej", "antonín", "aron", "artur", "augustin", "benjamín", "benedikt", "bohumil",
  "bohuslav", "bojan", "boris", "bořivoj", "břetislav", "ctibor", "ctirad", "dalibor",
  "damian", "daniel", "daněš", "david", "denis", "dominik", "dušan", "eduard", "egon", "emil",
  "erik", "ernest", "eugen", "fabian", "ferdinand", "filip", "florián", "františek", "gabriel",
  "gustav", "hanuš", "herman", "hugo", "igor", "ilja", "iliáš", "inocenc", "isidor", "ivo",
  "ivoš", "ivan", "jakub", "jan", "jáchym", "jindřich", "jiří", "jozef", "josef", "julius",
  "justin", "kašpar", "klement", "koloman", "kristián", "kryštof", "kunhart", "kuneš",
  "leopold", "libor", "liboslav", "luděk", "ludvík", "lubomír", "lubor", "luboš", "marián",
  "mario", "marius", "martin", "matouš", "matěj", "matyáš", "maxmilián", "mečislav",
  "metoděj", "michal", "milan", "miloslav", "milota", "mirek", "miroslav", "mojmír",
  "nikita", "norbert", "oldřich", "oliver", "ondřej", "osvald", "oslav", "otto", "pavel",
  "patrik", "petr", "prokop", "purkart", "radim", "radomír", "radovan", "radoslav", "radek",
  "richard", "robert", "robin", "roman", "rostislav", "ruben", "rudolf", "samuel", "sebastian",
  "silvestr", "simon", "slaven", "slavomír", "stanislav", "šimon", "štědrý", "štěpán",
  "tadeáš", "teodor", "tibor", "tomáš", "urban", "václav", "vavřinec", "vendelín", "victor",
  "viktor", "vincent", "vítek", "vladimír", "vlastimil", "vlastislav", "vojtěch", "voršlík",
  "vratislav", "zbyšek", "zbyněk", "zdeněk", "zikmund", "zoroslav",
];

/** Chlapecké přezdívky, které končí na -a (v češtině sedí na ženská pravidla). */
export const MALE_A_NICKNAMES: string[] = [
  "kuba", "jirka", "jenda", "vojta", "tonda", "franta", "honza", "láďa", "pepa", "béďa",
  "míra", "kája", "fanda", "vencouš", "maty", "krista",
];

const VOWELS = "áaeěiouůyýé";

function normalize(name: string) {
  return name.trim().toLowerCase().replace(/\s+/g, "");
}

/**
 * Vrátí "holka" | "kluk" podle jména, nebo null, když jméno nelze určit.
 */
export function genderFromName(name: string | null | undefined): "kluk" | "holka" | null {
  const n = normalize(name ?? "");
  if (!n) return null;
  if (FEMALE_NAMES.includes(n)) return "holka";
  if (MALE_NAMES.includes(n)) return "kluk";
  if (MALE_A_NICKNAMES.includes(n)) return "kluk";

  const first = n.split(/[^a-záčďéňóřůšťúžěíý]/i)[0] ?? "";
  if (FEMALE_NAMES.includes(first)) return "holka";
  if (MALE_NAMES.includes(first)) return "kluk";

  const last = n[n.length - 1] ?? "";
  if (n.endsWith("ová") || n.endsWith("ů")) return "holka";
  if (last === "o") return "kluk";
  if (VOWELS.includes(last)) return "holka";
  return "kluk";
}
