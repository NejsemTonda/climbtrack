import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const WEEKDAYS_CS = ["", "Pondělí", "Úterý", "Středa", "Čtvrtek"] as const;
export const WEEKDAYS_SHORT = ["", "Po", "Út", "St", "Čt"] as const;

export const GRADES = [
  "3", "4-", "4", "4+", "5-", "5", "5+", "6a", "6a+", "6b", "6b+",
  "6c", "6c+", "7a", "7a+", "7b", "7b+", "7c", "8a",
] as const;

export const STYLES = ["top rope", "na prvním"] as const;

// Body za vylezenou cestu: 2 za top rope, 4 za cestu na prvním
export const STYLE_POINTS: Record<string, number> = {
  "top rope": 2,
  "na prvním": 4,
};

export function pointsForStyle(style: string | null | undefined) {
  return STYLE_POINTS[style ?? ""] ?? 0;
}

type ClimbForPoints = {
  style: string | null;
  route_id?: string | null;
  route_color?: string | null;
  chain_number?: number | null;
  id?: string;
};

function routeKey(cl: ClimbForPoints) {
  if (cl.route_color && cl.chain_number) return `${cl.route_color}#${cl.chain_number}`;
  if (cl.route_id) return `r:${cl.route_id}`;
  return `c:${cl.id ?? Math.random()}`;
}

// Každá cesta se dítěti počítá jen jednou — nejlepší styl (na prvním 4 > top rope 2)
export function totalPoints(climbs: ClimbForPoints[]) {
  const best = new Map<string, number>();
  for (const cl of climbs) {
    const k = routeKey(cl);
    best.set(k, Math.max(best.get(k) ?? 0, pointsForStyle(cl.style)));
  }
  let sum = 0;
  for (const v of best.values()) sum += v;
  return sum;
}

export const ROUTE_COLORS = [
  { id: "bílá", cls: "bg-white border border-border" },
  { id: "šedá", cls: "bg-slate-400" },
  { id: "černá", cls: "bg-slate-800" },
  { id: "žlutá", cls: "bg-yellow-400" },
  { id: "oranžová", cls: "bg-orange-500" },
  { id: "červená", cls: "bg-red-500" },
  { id: "vínová", cls: "bg-rose-800" },
  { id: "fialová", cls: "bg-purple-500" },
  { id: "zelená", cls: "bg-green-500" },
  { id: "modrá", cls: "bg-blue-500" },
  { id: "písková", cls: "bg-amber-200" },
] as const;

export function colorCls(color: string | null | undefined) {
  return ROUTE_COLORS.find((c) => c.id === color)?.cls ?? "bg-muted";
}

// ===== Kroužkové časy: každý má vlastní barvu, aby se v tom vyznalo na první pohled =====
export type SlotMeta = {
  start: string;
  end: string;
  label: string;
  dot: string;
  text: string;
  chip: string;
  tint: string;
  solid: string;
};

export const SLOTS: [SlotMeta, SlotMeta, SlotMeta] = [
  {
    start: "14:30",
    end: "16:00",
    label: "14:30–16:00",
    dot: "bg-slot-1",
    text: "text-slot-1",
    chip: "bg-slot-1/15 text-slot-1",
    tint: "glass-tint-1",
    solid: "bg-slot-1",
  },
  {
    start: "16:00",
    end: "17:30",
    label: "16:00–17:30",
    dot: "bg-slot-2",
    text: "text-slot-2",
    chip: "bg-slot-2/15 text-slot-2",
    tint: "glass-tint-2",
    solid: "bg-slot-2",
  },
  {
    start: "17:30",
    end: "19:00",
    label: "17:30–19:00",
    dot: "bg-slot-3",
    text: "text-slot-3",
    chip: "bg-slot-3/15 text-slot-3",
    tint: "glass-tint-3",
    solid: "bg-slot-3",
  },
];

export function slotOf(startTime: string | null | undefined) {
  return SLOTS.find((s) => (startTime ?? "").startsWith(s.start)) ?? SLOTS[0];
}

// ===== Úrovně dětí: zelená / červená / černá =====
export type LevelMeta = { label: string; text: string; chip: string; dot: string };
export type LevelKey = "začátečník" | "mírně pokročilé" | "master";

export const LEVEL_META: Record<LevelKey, LevelMeta> = {
    "začátečník": {
      label: "začátečník",
      text: "text-lvl-beginner",
      chip: "bg-lvl-beginner/15 text-lvl-beginner",
      dot: "bg-lvl-beginner",
    },
    "mírně pokročilé": {
      label: "mírně pokročilé",
      text: "text-lvl-mid",
      chip: "bg-lvl-mid/15 text-lvl-mid",
      dot: "bg-lvl-mid",
    },
    "master": {
      label: "master",
      text: "text-lvl-master",
      chip: "bg-lvl-master/10 text-lvl-master",
      dot: "bg-lvl-master",
    },
  };

export function levelMeta(level: string | null | undefined): LevelMeta {
  return LEVEL_META[(level ?? "začátečník") as LevelKey] ?? LEVEL_META["začátečník"];
}

// ===== Styly přelezu: top rope / na prvním =====
export const STYLE_META: Record<string, { label: string; chip: string }> = {
  "top rope": { label: "top rope", chip: "bg-slot-1/15 text-slot-1" },
  "na prvním": { label: "na prvním", chip: "bg-forest/15 text-forest" },
};

export function styleMeta(style: string | null | undefined) {
  return (
    STYLE_META[style ?? ""] ?? {
      label: style ?? "",
      chip: "bg-secondary text-secondary-foreground",
    }
  );
}



export const routesQuery = () =>
  queryOptions({
    queryKey: ["routes"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("routes")
        .select("*")
        .order("chain_number")
        .order("color");
      if (error) throw error;
      return data;
    },
  });

export function formatTime(t: string) {
  return t.slice(0, 5);
}

export function levelForYears(years: number | null | undefined) {
  if (years == null) return null;
  if (years > 4) return "master";
  if (years > 2) return "mírně pokročilé";
  return "začátečník";
}

export function todayWeekday() {
  // JS: 0=Sun..6=Sat → our groups use 1=Mon..4=Thu
  return new Date().getDay();
}

export const groupsQuery = () =>
  queryOptions({
    queryKey: ["groups"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("groups")
        .select("*")
        .order("weekday")
        .order("start_time");
      if (error) throw error;
      return data;
    },
  });

export const childrenQuery = (groupId: string) =>
  queryOptions({
    queryKey: ["children", groupId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("children")
        .select("*")
        .eq("group_id", groupId)
        .order("first_name");
      if (error) throw error;
      return data;
    },
  });

export const allChildrenQuery = () =>
  queryOptions({
    queryKey: ["children", "all"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("children")
        .select("*")
        .order("first_name");
      if (error) throw error;
      return data;
    },
  });

export const groupClimbsQuery = (groupId: string) =>
  queryOptions({
    queryKey: ["climbs", "group", groupId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("climbs")
        .select("*, children(first_name, last_name)")
        .eq("group_id", groupId)
        .order("climbed_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      return data;
    },
  });

export const allClimbsQuery = () =>
  queryOptions({
    queryKey: ["climbs", "all"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("climbs")
        .select("id, child_id, style");
      if (error) throw error;
      return data;
    },
  });

export const childClimbsQuery = (childId: string) =>
  queryOptions({
    queryKey: ["climbs", "child", childId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("climbs")
        .select("*")
        .eq("child_id", childId)
        .order("climbed_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });


export const childQuery = (childId: string) =>
  queryOptions({
    queryKey: ["child", childId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("children")
        .select("*, groups(name, weekday, start_time, end_time)")
        .eq("id", childId)
        .single();
      if (error) throw error;
      return data;
    },
  });

// ===== Soutěž Lezík (14denní výzvy, odměna v lezících) =====
export const currentChallengeQuery = () =>
  queryOptions({
    queryKey: ["lezik", "current"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("lezik_challenges")
        .select("*, lezik_tasks(*)")
        .order("starts_on", { ascending: false })
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      if (data) data.lezik_tasks.sort((a, b) => a.position - b.position);
      return data;
    },
  });

export const allLezikQuery = () =>
  queryOptions({
    queryKey: ["lezik", "completions", "all"],
    queryFn: async () => {
      const { data, error } = await supabase.from("lezik_completions").select("child_id, reward");
      if (error) throw error;
      return data;
    },
  });

export const childLezikQuery = (childId: string) =>
  queryOptions({
    queryKey: ["lezik", "completions", "child", childId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("lezik_completions")
        .select("*")
        .eq("child_id", childId)
        .order("completed_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

export function lezikLabel(n: number) {
  if (n === 1) return "lezík";
  if (n >= 2 && n <= 4) return "lezíky";
  return "lezíků";
}
