import { createFileRoute } from "@tanstack/react-router";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { routesQuery, ROUTE_COLORS, colorCls } from "@/lib/queries";

export const Route = createFileRoute("/_authenticated/cesty")({
  head: () => ({
    meta: [
      { title: "Cesty na stěně — HC4" },
      { name: "description", content: "Seznam cest na lezecké stěně podle barvy a čísla řetězu." },
      { property: "og:title", content: "Cesty na stěně — HC4" },
      { property: "og:description", content: "Správa cest na stěně pro instruktory." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RoutesPage,
});

function RoutesPage() {
  const queryClient = useQueryClient();
  const { data: routes } = useSuspenseQuery(routesQuery());
  const [color, setColor] = useState("");
  const [chain, setChain] = useState("");
  const [saving, setSaving] = useState(false);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    const n = Number(chain);
    if (!color || !Number.isInteger(n) || n < 1 || n > 999) {
      toast.error("Vyberte barvu a zadejte číslo řetězu");
      return;
    }
    if (routes.some((r) => r.color === color && r.chain_number === n)) {
      toast.error("Tato cesta už v seznamu je");
      return;
    }
    setSaving(true);
    const { error } = await supabase.from("routes").insert({ color, chain_number: n });
    setSaving(false);
    if (error) {
      toast.error("Cestu se nepodařilo přidat");
      return;
    }
    toast.success("Cesta přidána");
    setChain("");
    await queryClient.invalidateQueries({ queryKey: ["routes"] });
  }

  async function remove(id: string) {
    if (!confirm("Odebrat cestu ze seznamu? Zapsané přelezy zůstanou.")) return;
    const { error } = await supabase.from("routes").delete().eq("id", id);
    if (error) {
      toast.error("Cestu se nepodařilo odebrat");
      return;
    }
    await queryClient.invalidateQueries({ queryKey: ["routes"] });
  }

  return (
    <AppShell>
      <div className="pt-4">
        <h1 className="flex items-center gap-2 text-xl font-extrabold tracking-tight">
          <span className="grid size-7 place-items-center rounded-xl bg-cesty/12 text-[14px] text-cesty-ink">
            ⛓
          </span>
          Cesty na stěně
        </h1>
        <p className="mt-1 text-xs text-muted-foreground">
          Přidejte cesty jednou — u dětí je pak jen vyberete při zápisu.
        </p>

        <form onSubmit={add} className="glass-card mt-3 space-y-3 p-4">
          <p className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
            Barva cesty
          </p>
          <div className="flex flex-wrap gap-2">
            {ROUTE_COLORS.map((c) => (
              <button
                key={c.id}
                type="button"
                title={c.id}
                onClick={() => setColor(c.id)}
                className={`size-8 rounded-full ${c.cls} ${color === c.id ? "ring-2 ring-ring ring-offset-2" : ""}`}
              />
            ))}
          </div>
          {color && <p className="text-[11px] font-bold text-cesty-ink">Barva: {color}</p>}
          <div className="flex gap-2">
            <input
              type="number"
              inputMode="numeric"
              min={1}
              max={999}
              value={chain}
              onChange={(e) => setChain(e.target.value)}
              placeholder="Číslo řetězu"
              className="w-full rounded-xl border border-input bg-card px-3 py-2.5 text-sm outline-none focus:border-ring"
            />
            <button
              type="submit"
              disabled={saving}
              className="shrink-0 rounded-xl bg-cesty px-5 text-sm font-semibold text-ink-foreground shadow-md shadow-cesty/30 disabled:opacity-60"
            >
              Přidat
            </button>
          </div>
        </form>

        <h2 className="mb-2.5 mt-6 flex items-center gap-2 text-[15px] font-bold tracking-tight">
          <span className="grid size-6 place-items-center rounded-lg bg-cesty/12 text-[12px] text-cesty-ink">
            ⛓
          </span>
          Seznam cest ({routes.length})
        </h2>
        <div className="space-y-2">
          {routes.length === 0 && (
            <p className="glass-card p-4 text-center text-sm text-muted-foreground">Zatím žádné cesty.</p>
          )}
          {routes.map((r) => (
            <div key={r.id} className="glass-chip flex items-center gap-3 px-3.5 py-2.5">
              <span className={`size-5 shrink-0 rounded-full ${colorCls(r.color)}`} />
              <p className="flex-1 text-[13px] font-semibold">
                Řetěz {r.chain_number} · {r.color}
              </p>
              <button onClick={() => remove(r.id)} className="text-xs font-semibold text-destructive">
                Odebrat
              </button>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
