import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { ChildAvatar, LevelChip } from "@/components/ChildAvatar";
import {
  allChildrenQuery,
  allClimbsQuery,
  allLezikQuery,
  groupsQuery,
  WEEKDAYS_CS,
  WEEKDAYS_SHORT,
  formatTime,
  totalPoints,
  LEVEL_META,
  SLOTS,
} from "@/lib/queries";

export const Route = createFileRoute("/_authenticated/deti")({
  head: () => ({
    meta: [
      { title: "Děti — HC4" },
      { name: "description", content: "Seznam všech dětí v lezeckých kroužcích." },
      { property: "og:title", content: "Děti — HC4" },
      { property: "og:description", content: "Seznam všech dětí v lezeckých kroužcích." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ChildrenPage,
});

const LEVELS = ["začátečník", "mírně pokročilé", "master"] as const;

function cestyWord(n: number) {
  if (n === 1) return "cesta";
  if (n >= 2 && n <= 4) return "cesty";
  return "cest";
}

type SortMode = "name" | "most" | "least" | "mostPoints" | "leastPoints";

function ChildrenPage() {
  const { data: children } = useSuspenseQuery(allChildrenQuery());
  const { data: groups } = useSuspenseQuery(groupsQuery());
  const { data: climbs } = useSuspenseQuery(allClimbsQuery());
  const { data: lezik } = useSuspenseQuery(allLezikQuery());
  const lezikMap = useMemo(() => {
    const m = new Map<string, number>();
    for (const l of lezik) m.set(l.child_id, (m.get(l.child_id) ?? 0) + l.reward);
    return m;
  }, [lezik]);

  const [search, setSearch] = useState("");
  const [day, setDay] = useState<number | null>(null);
  const [time, setTime] = useState<string | null>(null);
  const [level, setLevel] = useState<string | null>(null);
  const [sort, setSort] = useState<SortMode>("name");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const activeFilterCount =
    (day !== null ? 1 : 0) +
    (time !== null ? 1 : 0) +
    (level !== null ? 1 : 0) +
    (sort !== "name" ? 1 : 0);

  const climbStats = useMemo(() => {
    const counts = new Map<string, number>();
    const points = new Map<string, number>();
    const byChild = new Map<string, typeof climbs>();
    for (const cl of climbs) {
      counts.set(cl.child_id, (counts.get(cl.child_id) ?? 0) + 1);
      byChild.set(cl.child_id, [...(byChild.get(cl.child_id) ?? []), cl]);
    }
    for (const [id, list] of byChild) points.set(id, totalPoints(list));
    return { counts, points };
  }, [climbs]);

  const groupOf = (groupId: string) => groups.find((g) => g.id === groupId);

  const filtered = useMemo(() => {
    const list = children.filter((c) => {
      if (!`${c.first_name}`.toLowerCase().includes(search.toLowerCase()))
        return false;
      const g = groupOf(c.group_id);
      if (day !== null && g?.weekday !== day) return false;
      if (time !== null && (!g || formatTime(g.start_time) !== time)) return false;
      if (level !== null && (c.level ?? "začátečník") !== level) return false;
      return true;
    });
    if (sort === "most") {
      list.sort((a, b) => (climbStats.counts.get(b.id) ?? 0) - (climbStats.counts.get(a.id) ?? 0));
    } else if (sort === "least") {
      list.sort((a, b) => (climbStats.counts.get(a.id) ?? 0) - (climbStats.counts.get(b.id) ?? 0));
    } else if (sort === "mostPoints") {
      list.sort((a, b) => (climbStats.points.get(b.id) ?? 0) - (climbStats.points.get(a.id) ?? 0));
    } else if (sort === "leastPoints") {
      list.sort((a, b) => (climbStats.points.get(a.id) ?? 0) - (climbStats.points.get(b.id) ?? 0));
    }
    return list;
  }, [children, groups, search, day, time, level, sort, climbStats]);

  const chip = (active: boolean, on = "bg-primary text-primary-foreground") =>
    `shrink-0 rounded-full px-3 py-1.5 text-[12px] font-bold transition-colors ${
      active ? on : "glass-chip text-muted-foreground"
    }`;

  return (
    <AppShell>
      <div className="pt-4">
        <h1 className="flex items-center gap-2 text-xl font-extrabold tracking-tight">
          <span className="grid size-7 place-items-center rounded-xl bg-deti/12 text-[14px] text-deti">
            ◍
          </span>
          Všechny děti
        </h1>
        <input
          type="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Hledat dítě…"
          className="glass-card mt-3 w-full px-4 py-2.5 text-sm outline-none placeholder:text-muted-foreground"
        />

        {/* Filtrovat */}
        <button
          className="glass-chip mt-3 flex w-full items-center justify-center gap-2 px-4 py-2.5 text-sm font-bold text-deti transition-transform active:scale-[0.98]"
          onClick={() => setFiltersOpen((o) => !o)}
        >
          <span
            aria-hidden
            className="grid size-4 place-items-center rounded-full bg-deti text-[10px] font-extrabold text-primary-foreground"
          >
            {activeFilterCount > 0 ? activeFilterCount : ""}
          </span>
          {filtersOpen ? "Skrýt filtry" : "Filtrovat"}
          <span aria-hidden className="text-xs">
            {filtersOpen ? "▲" : "▼"}
          </span>
        </button>
        {filtersOpen && (
          <>
            {/* Den — fialová */}
            <div className="mt-3 flex gap-1.5 overflow-x-auto pb-1">
              <button className={chip(day === null, "bg-deti text-primary-foreground")} onClick={() => setDay(null)}>
                Všechny dny
              </button>
              {[1, 2, 3, 4].map((d) => (
                <button
                  key={d}
                  className={chip(day === d, "bg-deti text-primary-foreground")}
                  onClick={() => setDay(day === d ? null : d)}
                >
                  {WEEKDAYS_CS[d]}
                </button>
              ))}
            </div>

            {/* Hodina — barva daného času */}
            <div className="mt-1.5 flex gap-1.5 overflow-x-auto pb-1">
              <button className={chip(time === null, "bg-deti text-primary-foreground")} onClick={() => setTime(null)}>
                Všechny časy
              </button>
              {SLOTS.map((s) => (
                <button
                  key={s.start}
                  className={chip(time === s.start, `${s.solid} text-primary-foreground`)}
                  onClick={() => setTime(time === s.start ? null : s.start)}
                >
                  od {s.start}
                </button>
              ))}
            </div>

            {/* Úroveň — zelená / červená / černá */}
            <div className="mt-1.5 flex gap-1.5 overflow-x-auto pb-1">
              <button className={chip(level === null, "bg-deti text-primary-foreground")} onClick={() => setLevel(null)}>
                Všechny úrovně
              </button>
              {LEVELS.map((l) => (
                <button
                  key={l}
                  className={chip(level === l, `${LEVEL_META[l].dot} text-primary-foreground`)}
                  onClick={() => setLevel(level === l ? null : l)}
                >
                  {l}
                </button>
              ))}
            </div>

            {/* Řazení — modrá */}
            <div className="mt-1.5 flex gap-1.5 overflow-x-auto pb-1">
              <button className={chip(sort === "name")} onClick={() => setSort("name")}>
                Podle jména
              </button>
              <button
                className={chip(sort === "mostPoints")}
                onClick={() => setSort("mostPoints")}
              >
                Nejvíc bodů
              </button>
              <button
                className={chip(sort === "leastPoints")}
                onClick={() => setSort("leastPoints")}
              >
                Nejméně bodů
              </button>
              <button className={chip(sort === "most")} onClick={() => setSort("most")}>
                Nejvíc cest
              </button>
              <button className={chip(sort === "least")} onClick={() => setSort("least")}>
                Nejméně cest
              </button>
            </div>
          </>
        )}

        <div className="mt-3 space-y-2">
          {filtered.length === 0 && (
            <p className="glass-card p-4 text-center text-sm text-muted-foreground">
              Nic nenalezeno.
            </p>
          )}
          {filtered.map((c) => {
            const g = groupOf(c.group_id);
            const count = climbStats.counts.get(c.id) ?? 0;
            const points = climbStats.points.get(c.id) ?? 0;
            return (
              <Link
                key={c.id}
                to="/dite/$childId"
                params={{ childId: c.id }}
                className="glass-chip flex items-center gap-2.5 px-3 py-2.5 transition-transform active:scale-[0.98]"
              >
                <ChildAvatar name={c.first_name} gender={c.gender} level={c.level} />
                <div className="flex-1">
                  <p className="text-[15px] font-extrabold tracking-tight text-foreground">
                    {c.first_name}
                  </p>
                  <div className="mt-1 flex flex-wrap items-center gap-1.5">
                    {g ? (
                      <span className="inline-flex items-center rounded-full bg-secondary px-2 py-0.5 text-[10px] font-bold text-muted-foreground">
                        {WEEKDAYS_SHORT[g.weekday]} {formatTime(g.start_time)}
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold text-muted-foreground">Bez kroužku</span>
                    )}
                    <LevelChip level={c.level} />
                  </div>
                </div>
                <div className="ml-auto shrink-0 pl-1 text-right leading-tight">
                  <p className="text-[11px] font-bold tabular-nums text-foreground">
                    {count} {cestyWord(count)}
                  </p>
                  <p className="text-[11px] font-bold tabular-nums text-muted-foreground">
                    {points} b · {lezikMap.get(c.id) ?? 0} L
                  </p>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </AppShell>
  );
}
