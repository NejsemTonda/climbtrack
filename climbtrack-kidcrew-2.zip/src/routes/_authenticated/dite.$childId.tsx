import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { AddClimbDialog } from "@/components/AddClimbDialog";
import { QuickClimbList } from "@/components/QuickClimbList";
import { LezikBox } from "@/components/LezikBox";
import { ChildAvatar, GenderPicker } from "@/components/ChildAvatar";
import { supabase } from "@/integrations/supabase/client";
import { genderFromName } from "@/lib/gender";
import {
  childQuery,
  childClimbsQuery,
  childLezikQuery,
  lezikLabel,
  formatTime,
  WEEKDAYS_CS,
  colorCls,
  levelForYears,
  pointsForStyle,
  totalPoints,
  styleMeta,
  slotOf,
} from "@/lib/queries";

export const Route = createFileRoute("/_authenticated/dite/$childId")({
  head: () => ({
    meta: [
      { title: "Dítě — HC4" },
      { name: "description", content: "Historie a statistiky vylezených cest dítěte." },
      { property: "og:title", content: "Dítě — HC4" },
      { property: "og:description", content: "Historie lezení dítěte v kroužku." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ChildDetail,
});

function ChildDetail() {
  const { childId } = Route.useParams();
  const { data: child } = useSuspenseQuery(childQuery(childId));
  const { data: climbs } = useSuspenseQuery(childClimbsQuery(childId));
  const { data: lezikDone = [] } = useQuery(childLezikQuery(childId));
  const [showAddClimb, setShowAddClimb] = useState(false);
  const [showEdit, setShowEdit] = useState(false);
  const [firstName, setFirstName] = useState(child.first_name);
  const [birthYear, setBirthYear] = useState(child.birth_year?.toString() ?? "");
  const [climbingYears, setClimbingYears] = useState(child.climbing_years?.toString() ?? "");
  const [gender, setGender] = useState(child.gender ?? "kluk");
  const [genderTouched, setGenderTouched] = useState(false);
  const queryClient = useQueryClient();

  async function saveChild(e: React.FormEvent) {
    e.preventDefault();
    const years = climbingYears === "" ? null : Number(climbingYears);
    const { error } = await supabase
      .from("children")
      .update({
        first_name: firstName,
        gender,
        
        birth_year: birthYear === "" ? null : Number(birthYear),
        climbing_years: years,
        level: levelForYears(years),
      })
      .eq("id", childId);
    if (error) {
      toast.error("Změny se nepodařilo uložit");
      return;
    }
    toast.success("Údaje upraveny");
    setShowEdit(false);
    await queryClient.invalidateQueries();
  }

  const points = totalPoints(climbs);
  const lezikTotal = lezikDone.reduce((s, d) => s + d.reward, 0);
  type H =
    | { kind: "climb"; at: string; cl: (typeof climbs)[number] }
    | { kind: "lezik"; at: string; id: string; title: string; reward: number };
  const history: H[] = [
    ...climbs.map((cl) => ({ kind: "climb" as const, at: cl.climbed_at, cl })),
    ...lezikDone.map((d) => ({
      kind: "lezik" as const,
      at: d.completed_at,
      id: d.id,
      title: d.task_title,
      reward: d.reward,
    })),
  ].sort((a, b) => b.at.localeCompare(a.at));
  const slot = slotOf(child.groups?.start_time);

  return (
    <AppShell>
      <div className="pt-4">
        <Link
          to="/skupina/$groupId"
          params={{ groupId: child.group_id }}
          className="text-xs font-semibold text-muted-foreground"
        >
          ← Zpět na kroužek
        </Link>

        <div
          className={`mt-2 flex items-center gap-3 p-4 ${
            child.gender === "holka" ? "glass-tint-girl" : "glass-tint-boy"
          }`}
        >
          <ChildAvatar name={child.first_name} gender={child.gender} level={child.level} size="lg" />
          <div className="flex-1">
            <h1 className="text-lg font-extrabold tracking-tight">
              {child.first_name}
            </h1>
            <p className="text-[11px] font-medium text-muted-foreground">
              {WEEKDAYS_CS[child.groups?.weekday ?? 1]}{" "}
              {child.groups ? `${formatTime(child.groups.start_time)}–${formatTime(child.groups.end_time)}` : ""}
              {child.birth_year ? ` · ${new Date().getFullYear() - child.birth_year} let` : ""}
              {child.level ? ` · ${child.level}` : ""}
            </p>
            {child.groups && (
              <span
                className={`mt-1.5 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold ${slot.chip}`}
              >
                <span className={`size-1.5 rounded-full ${slot.dot}`} />
                {slot.label}
              </span>
            )}
          </div>
          <button
            onClick={() => setShowEdit(!showEdit)}
            className="shrink-0 rounded-xl bg-card px-3 py-2 text-[11px] font-semibold text-foreground/80 shadow-sm"
          >
            {showEdit ? "Zavřít" : "Upravit"}
          </button>
        </div>

        {showEdit && (
          <form onSubmit={saveChild} className="glass-card mt-3 space-y-2 p-4">
            <GenderPicker
              value={gender}
              onChange={(v) => {
                setGender(v);
                setGenderTouched(true);
              }}
            />
            <input
              required
              value={firstName}
              onChange={(e) => {
                setFirstName(e.target.value);
                if (!genderTouched) {
                  const g = genderFromName(e.target.value);
                  if (g) setGender(g);
                }
              }}
              placeholder="Jméno"
              className="w-full rounded-xl border border-input bg-card px-3 py-2.5 text-sm outline-none focus:border-ring"
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                required
                type="number"
                min={1940}
                max={new Date().getFullYear()}
                value={birthYear}
                onChange={(e) => setBirthYear(e.target.value)}
                placeholder="Rok narození"
                className="w-full rounded-xl border border-input bg-card px-3 py-2.5 text-sm outline-none focus:border-ring"
              />
              <input
                required
                type="number"
                min={0}
                max={60}
                value={climbingYears}
                onChange={(e) => setClimbingYears(e.target.value)}
                placeholder="Kolik let leze"
                className="w-full rounded-xl border border-input bg-card px-3 py-2.5 text-sm outline-none focus:border-ring"
              />
            </div>
            {climbingYears !== "" && (
              <p className="text-[11px] font-medium text-muted-foreground">
                Úroveň: <span className="font-bold text-primary">{levelForYears(Number(climbingYears))}</span>
              </p>
            )}
            <button
              type="submit"
              className="w-full rounded-xl bg-primary py-2.5 text-sm font-semibold text-primary-foreground shadow-md shadow-primary/30"
            >
              Uložit změny
            </button>
          </form>
        )}

        <QuickClimbList childId={child.id} groupId={child.group_id} climbs={climbs} />

        <LezikBox childId={child.id} level={child.level} />

        <h2 className="mb-2.5 mt-6 flex items-center gap-2 text-[15px] font-bold tracking-tight">
          <span className="grid size-6 place-items-center rounded-lg bg-primary/12 text-[12px] text-primary">
            ⛰
          </span>
          Historie
          <span className="ml-auto flex gap-1.5">
            <span className="rounded-full bg-primary/10 px-2 py-0.5 text-[11px] font-bold text-primary">
              {points} b
            </span>
            <span className="rounded-full bg-amber/20 px-2 py-0.5 text-[11px] font-bold text-amber">
              {lezikTotal} {lezikLabel(lezikTotal)}
            </span>
          </span>
        </h2>
        <div className="space-y-2">
          {history.length === 0 && (
            <p className="glass-card p-4 text-center text-sm text-muted-foreground">
              Zatím žádná historie.
            </p>
          )}
          {history.map((h) =>
            h.kind === "lezik" ? (
              <div key={h.id} className="glass-chip flex items-center gap-2.5 px-3.5 py-3">
                <span className="grid size-7 place-items-center rounded-lg bg-amber/20 text-[13px] text-amber">◎</span>
                <p className="flex-1 text-[13px] font-semibold">{h.title}</p>
                <span className="text-[11px] font-bold text-amber">
                  +{h.reward} {lezikLabel(h.reward)}
                </span>
                <span className="text-[11px] text-muted-foreground">
                  {new Date(h.at).toLocaleDateString("cs-CZ")}
                </span>
              </div>
            ) : (
              <div key={h.cl.id} className="glass-chip px-3.5 py-3">
                <div className="flex items-center gap-2.5">
                  <span className="grade-badge flex items-center gap-1 bg-secondary text-secondary-foreground">
                    <span className={`size-2.5 rounded-full ${colorCls(h.cl.route_color)}`} />
                    {h.cl.chain_number ?? h.cl.grade}
                  </span>
                  <div className="flex-1">
                    <p className="text-[13px] font-semibold">
                      {h.cl.route_color ?? "Cesta"}
                      {h.cl.chain_number ? ` · řetěz ${h.cl.chain_number}` : ""}
                    </p>
                    <div className="mt-1 flex flex-wrap items-center gap-1.5">
                      <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${styleMeta(h.cl.style).chip}`}>
                        {styleMeta(h.cl.style).label}
                      </span>
                    </div>
                  </div>
                  <span className="text-[11px] font-bold text-primary">+{pointsForStyle(h.cl.style)} b</span>
                  <span className="text-[11px] text-muted-foreground">
                    {new Date(h.at).toLocaleDateString("cs-CZ")}
                  </span>
                </div>
                {h.cl.note && (
                  <p className="mt-2 rounded-lg bg-secondary/60 px-2.5 py-1.5 text-[12px] text-muted-foreground">
                    {h.cl.note}
                  </p>
                )}
              </div>
            ),
          )}
        </div>
      </div>

      {showAddClimb && (
        <AddClimbDialog
          groupId={child.group_id}
          childId={child.id}
          onClose={() => setShowAddClimb(false)}
        />
      )}
    </AppShell>
  );
}
