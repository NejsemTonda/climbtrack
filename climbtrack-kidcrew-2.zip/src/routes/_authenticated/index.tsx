import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { groupsQuery, formatTime, todayWeekday, WEEKDAYS_CS, slotOf } from "@/lib/queries";

export const Route = createFileRoute("/_authenticated/")({
  head: () => ({
    meta: [
      { title: "Kroužky — HC4" },
      {
        name: "description",
        content: "Přehled lezeckých kroužků od pondělí do čtvrtka a záznamy vylezených cest.",
      },
      { property: "og:title", content: "Kroužky — HC4" },
      { property: "og:description", content: "Přehled lezeckých kroužků a evidence lezení." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const { data: groups } = useSuspenseQuery(groupsQuery());
  const today = todayWeekday();
  const [day, setDay] = useState(today >= 1 && today <= 4 ? today : 1);
  const shift = (d: number) => setDay((cur) => ((cur - 1 + d + 4) % 4) + 1);
  const dayGroups = groups
    .filter((g) => g.weekday === day)
    .sort((a, b) => a.start_time.localeCompare(b.start_time));

  return (
    <AppShell>
      <div className="mt-4 flex items-center gap-3">
        <button
          type="button"
          aria-label="Předchozí den"
          onClick={() => shift(-1)}
          className="grid size-9 shrink-0 place-items-center rounded-full bg-krouzky/12 text-krouzky transition-transform active:scale-90"
        >
          <ChevronLeft className="size-6" strokeWidth={3} />
        </button>
        <div className="flex-1 text-center">
          <p className="text-[22px] font-extrabold tracking-tight">{WEEKDAYS_CS[day]}</p>
          {day === today && (
            <span className="text-[11px] font-bold uppercase tracking-wider text-krouzky">Dnes</span>
          )}
        </div>
        <button
          type="button"
          aria-label="Další den"
          onClick={() => shift(1)}
          className="grid size-9 shrink-0 place-items-center rounded-full bg-krouzky/12 text-krouzky transition-transform active:scale-90"
        >
          <ChevronRight className="size-6" strokeWidth={3} />
        </button>
      </div>

      <div className="mt-5 space-y-3">
        {dayGroups.map((g) => {
          const slot = slotOf(g.start_time);
          return (
            <Link
              key={g.id}
              to="/skupina/$groupId"
              params={{ groupId: g.id }}
              className={`${slot.tint} flex items-center gap-3 p-5 transition-transform active:scale-[0.98]`}
            >
              <div className="flex-1">
                <p className="text-[20px] font-extrabold tracking-tight">
                  {formatTime(g.start_time)}–{formatTime(g.end_time)}
                </p>
                <p className={`mt-0.5 text-[11px] font-bold ${slot.text}`}>Otevřít kroužek</p>
              </div>
              <span
                className={`grid size-7 shrink-0 place-items-center rounded-full text-primary-foreground ${slot.solid}`}
              >
                <ChevronRight className="size-4" strokeWidth={3.5} />
              </span>
            </Link>
          );
        })}
      </div>
    </AppShell>
  );
}
