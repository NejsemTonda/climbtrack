import { createFileRoute } from "@tanstack/react-router";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { currentChallengeQuery, lezikLabel, levelMeta } from "@/lib/queries";

export const Route = createFileRoute("/_authenticated/lezik")({
  head: () => ({
    meta: [
      { title: "Lezík — 14denní výzvy" },
      { name: "description", content: "Soutěž Lezík: tři úkoly na 14 dní, odměna v lezících." },
      { property: "og:title", content: "Lezík — 14denní výzvy" },
      { property: "og:description", content: "Aktuální výzva soutěže Lezík pro všechny kroužky." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(currentChallengeQuery());
  },
  component: LezikPage,
});

const fmt = (d: string) => new Date(d).toLocaleDateString("cs-CZ");
const inputCls =
  "w-full rounded-xl border border-input bg-card px-3 py-2.5 text-sm outline-none focus:border-ring";

type TaskRow = { id?: string; title: string; reward: string; levels: string[] };
const LEVELS = ["začátečník", "mírně pokročilé", "master"] as const;

const emptyRows = (): TaskRow[] => [
  { title: "", reward: "1", levels: [] },
  { title: "", reward: "1", levels: [] },
  { title: "", reward: "1", levels: [] },
];

function LezikPage() {
  const queryClient = useQueryClient();
  const { data: challenge } = useSuspenseQuery(currentChallengeQuery());
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(false);
  const today = new Date().toISOString().slice(0, 10);
  const [title, setTitle] = useState("");
  const [startsOn, setStartsOn] = useState(today);
  const [tasks, setTasks] = useState<TaskRow[]>(emptyRows());
  const [editTitle, setEditTitle] = useState("");
  const [editStartsOn, setEditStartsOn] = useState(today);
  const [editTasks, setEditTasks] = useState<TaskRow[]>(emptyRows());
  const [saving, setSaving] = useState(false);

  function setTask(rows: TaskRow[], setRows: (r: TaskRow[]) => void, i: number, key: "title" | "reward", v: string) {
    setRows(rows.map((x, j) => (j === i ? { ...x, [key]: v } : x)));
  }

  function toggleLevel(rows: TaskRow[], setRows: (r: TaskRow[]) => void, i: number, lvl: string) {
    setRows(
      rows.map((x, j) =>
        j === i
          ? { ...x, levels: x.levels.includes(lvl) ? x.levels.filter((l) => l !== lvl) : [...x.levels, lvl] }
          : x,
      ),
    );
  }

  function levelPicker(rows: TaskRow[], setRows: (r: TaskRow[]) => void, i: number) {
    return (
      <div className="flex flex-wrap gap-1.5 pb-1">
        {LEVELS.map((l) => {
          const m = levelMeta(l);
          const on = rows[i]?.levels.includes(l) ?? false;
          return (
            <button
              key={l}
              type="button"
              onClick={() => toggleLevel(rows, setRows, i, l)}
              className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${on ? `${m.dot} text-primary-foreground` : "border border-input bg-card text-muted-foreground"}`}
            >
              {l}
            </button>
          );
        })}
      </div>
    );
  }

  function addRow(rows: TaskRow[], setRows: (r: TaskRow[]) => void) {
    if (rows.length >= 6) return;
    setRows([...rows, { title: "", reward: "1", levels: [] }]);
  }

  function removeRow(rows: TaskRow[], setRows: (r: TaskRow[]) => void, i: number) {
    if (rows.length <= 1) return;
    setRows(rows.filter((_, j) => j !== i));
  }

  function startEdit() {
    if (!challenge) return;
    setEditTitle(challenge.title ?? "");
    setEditStartsOn(challenge.starts_on);
    const rows: TaskRow[] = challenge.lezik_tasks.map((t) => ({
      id: t.id,
      title: t.title,
      reward: String(t.reward),
      levels: t.levels ?? [],
    }));
    while (rows.length < 3) rows.push({ title: "", reward: "1", levels: [] });
    setEditTasks(rows);
    setEditing(true);
    setOpen(false);
  }

  async function create(e: React.FormEvent) {
    e.preventDefault();
    if (
      challenge &&
      !confirm(
        "Nová výzva ukončí tu současnou. Získané lezíky dětem zůstanou. Pokračovat?",
      )
    )
      return;
    setSaving(true);
    const end = new Date(startsOn);
    end.setDate(end.getDate() + 13);
    const { data, error } = await supabase
      .from("lezik_challenges")
      .insert({ title, starts_on: startsOn, ends_on: end.toISOString().slice(0, 10) })
      .select()
      .single();
    if (error || !data) {
      setSaving(false);
      toast.error("Výzvu se nepodařilo vytvořit");
      return;
    }
    const { error: e2 } = await supabase.from("lezik_tasks").insert(
      tasks.map((t, i) => ({
        challenge_id: data.id,
        title: t.title.trim(),
        reward: Math.max(1, Number(t.reward) || 1),
        levels: t.levels,
        position: i,
      })),
    );
    setSaving(false);
    if (e2) {
      toast.error("Úkoly se nepodařilo uložit");
      return;
    }
    toast.success("Nová výzva vyhlášena");
    setOpen(false);
    setTitle("");
    setTasks(emptyRows());
    await queryClient.invalidateQueries({ queryKey: ["lezik"] });
  }

  async function saveEdit(e: React.FormEvent) {
    e.preventDefault();
    if (!challenge) return;
    setSaving(true);

    const end = new Date(editStartsOn);
    end.setDate(end.getDate() + 13);
    const { error } = await supabase
      .from("lezik_challenges")
      .update({
        title: editTitle.trim(),
        starts_on: editStartsOn,
        ends_on: end.toISOString().slice(0, 10),
      })
      .eq("id", challenge.id);
    if (error) {
      setSaving(false);
      toast.error("Výzvu se nepodařilo upravit");
      return;
    }

    // úkoly, které uživatelka odebrala — dětem už připsané lezíky zůstanou
    const kept = new Set(editTasks.filter((t) => t.id).map((t) => t.id));
    const removed = challenge.lezik_tasks.filter((t) => !kept.has(t.id)).map((t) => t.id);
    if (removed.length > 0) {
      const { error: eDel } = await supabase.from("lezik_tasks").delete().in("id", removed);
      if (eDel) {
        setSaving(false);
        toast.error("Úkoly se nepodařilo upravit");
        return;
      }
    }

    for (const t of editTasks.filter(
      (x): x is TaskRow & { id: string } => Boolean(x.id),
    )) {
      const { error: eUp } = await supabase
        .from("lezik_tasks")
        .update({ title: t.title.trim(), reward: Math.max(1, Number(t.reward) || 1), levels: t.levels })
        .eq("id", t.id);
      if (eUp) {
        setSaving(false);
        toast.error("Úkoly se nepodařilo uložit");
        return;
      }
    }

    const fresh = editTasks.filter((x) => !x.id && x.title.trim());
    if (fresh.length > 0) {
      const { error: eIns } = await supabase.from("lezik_tasks").insert(
        fresh.map((t, i) => ({
          challenge_id: challenge.id,
          title: t.title.trim(),
          reward: Math.max(1, Number(t.reward) || 1),
          levels: t.levels,
          position: challenge.lezik_tasks.length + i,
        })),
      );
      if (eIns) {
        setSaving(false);
        toast.error("Nové úkoly se nepodařilo přidat");
        return;
      }
    }

    setSaving(false);
    toast.success("Výzva upravena");
    setEditing(false);
    await queryClient.invalidateQueries({ queryKey: ["lezik"] });
  }

  const editEnd = new Date(editStartsOn);
  editEnd.setDate(editEnd.getDate() + 13);

  return (
    <AppShell>
      <div className="pt-4">
        <h1 className="flex items-center gap-2 text-xl font-extrabold tracking-tight">
          <span className="grid size-7 place-items-center rounded-xl bg-amber/15 text-[14px] text-amber">
            ◎
          </span>
          Lezík
        </h1>
        <p className="text-[12px] text-muted-foreground">
          14denní výzva pro všechny kroužky. Každé dítě si vybere a splní nejvýš 2 úkoly.
        </p>

        {challenge ? (
          <div className="glass-tint-lezik mt-3 p-4">
            <p className="text-[10px] font-semibold uppercase tracking-wider text-amber">
              Aktuální výzva · {fmt(challenge.starts_on)} – {fmt(challenge.ends_on)}
            </p>
            {challenge.title && <p className="mt-1 text-[15px] font-bold">{challenge.title}</p>}
            <div className="mt-3 space-y-2">
              {challenge.lezik_tasks.map((t, i) => (
                <div key={t.id} className="glass-chip flex items-center gap-3 px-3.5 py-3">
                  <span className="grid size-7 place-items-center rounded-full bg-amber/20 text-[12px] font-bold text-amber">
                    {i + 1}
                  </span>
                  <div className="flex-1">
                    <p className="text-[13px] font-semibold">{t.title}</p>
                    <div className="mt-1 flex flex-wrap gap-1">
                      {(t.levels.length ? t.levels : ["všichni"]).map((l) => (
                        <span key={l} className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${l === "všichni" ? "bg-secondary text-secondary-foreground" : levelMeta(l).chip}`}>{l}</span>
                      ))}
                    </div>
                  </div>
                  <span className="rounded-full bg-amber/20 px-2 py-0.5 text-[11px] font-bold text-amber">
                    {t.reward} {lezikLabel(t.reward)}
                  </span>
                </div>
              ))}
            </div>
            <p className="mt-3 text-[11px] text-muted-foreground">
              Splnění zapíšete na kartě dítěte (klikněte na jméno dítěte).
            </p>
            <button
              onClick={() => (editing ? setEditing(false) : startEdit())}
              className="mt-3 w-full rounded-xl border border-amber/40 bg-card py-2.5 text-sm font-bold text-amber transition-transform active:scale-[0.98]"
            >
              {editing ? "Zavřít úpravy" : "✎ Upravit výzvu"}
            </button>
            <button
              onClick={async () => {
                if (!confirm("Smazat tuto výzvu? Lezíci, které děti už získaly, jim zůstanou.")) return;
                const { error } = await supabase.from("lezik_challenges").delete().eq("id", challenge.id);
                if (error) {
                  toast.error("Výzvu se nepodařilo smazat");
                  return;
                }
                toast.success("Výzva smazána");
                setEditing(false);
                await queryClient.invalidateQueries({ queryKey: ["lezik"] });
              }}
              className="mt-2 w-full rounded-xl py-2 text-[12px] font-semibold text-destructive"
            >
              Smazat výzvu
            </button>
          </div>
        ) : (
          <p className="glass-card mt-3 p-4 text-center text-sm text-muted-foreground">
            Zatím není vyhlášená žádná výzva.
          </p>
        )}

        {editing && challenge && (
          <form onSubmit={saveEdit} className="glass-card mt-3 space-y-2 p-4">
            <p className="text-[11px] font-bold uppercase tracking-wider text-amber">
              Úpravy aktuální výzvy
            </p>
            <input
              value={editTitle}
              onChange={(e) => setEditTitle(e.target.value)}
              placeholder="Název výzvy (nepovinné)"
              className={inputCls}
            />
            <label className="block text-[11px] font-semibold text-muted-foreground">
              Začátek (trvá 14 dní, do {fmt(editEnd.toISOString().slice(0, 10))})
              <input
                type="date"
                required
                value={editStartsOn}
                onChange={(e) => setEditStartsOn(e.target.value)}
                className={`${inputCls} mt-1`}
              />
            </label>
            {editTasks.map((t, i) => (
              <div key={t.id ?? `new-${i}`} className="space-y-1.5"><div className="flex gap-2">
                <input
                  required
                  value={t.title}
                  onChange={(e) => setTask(editTasks, setEditTasks, i, "title", e.target.value)}
                  placeholder={`Úkol ${i + 1}`}
                  className={inputCls}
                />
                <input
                  required
                  type="number"
                  min={1}
                  max={100}
                  value={t.reward}
                  onChange={(e) => setTask(editTasks, setEditTasks, i, "reward", e.target.value)}
                  aria-label={`Lezíky za úkol ${i + 1}`}
                  className={`${inputCls} w-20 text-center`}
                />
                <button
                  type="button"
                  onClick={() => removeRow(editTasks, setEditTasks, i)}
                  aria-label={`Odebrat úkol ${i + 1}`}
                  className="shrink-0 rounded-xl border border-input bg-card px-3 text-sm font-bold text-destructive"
                >
                  ✕
                </button>
              </div>{levelPicker(editTasks, setEditTasks, i)}</div>
            ))}
            <button
              type="button"
              onClick={() => addRow(editTasks, setEditTasks)}
              className="w-full rounded-xl border border-dashed border-amber/50 py-2 text-[12px] font-bold text-amber"
            >
              ＋ Přidat úkol
            </button>
            <p className="text-[11px] text-muted-foreground">
              Zrušený úkol zmizí ze seznamu, ale lezíky, které už děti získaly, jim zůstanou.
            </p>
            <button
              disabled={saving}
              type="submit"
              className="w-full rounded-xl bg-amber py-2.5 text-sm font-bold text-primary-foreground disabled:opacity-60"
            >
              {saving ? "Ukládám…" : "Uložit úpravy"}
            </button>
          </form>
        )}

        {!editing && (
          <>
            <button
              onClick={() => setOpen(!open)}
              className="mt-3 w-full rounded-2xl bg-primary py-3 text-sm font-bold text-primary-foreground shadow-lg shadow-primary/30"
            >
              {open ? "Zavřít" : "＋ Nová 14denní výzva"}
            </button>

            {open && (
              <form onSubmit={create} className="glass-card mt-3 space-y-2 p-4">
                <input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Název výzvy (nepovinné)"
                  className={inputCls}
                />
                <label className="block text-[11px] font-semibold text-muted-foreground">
                  Začátek (trvá 14 dní)
                  <input
                    type="date"
                    required
                    value={startsOn}
                    onChange={(e) => setStartsOn(e.target.value)}
                    className={`${inputCls} mt-1`}
                  />
                </label>
                {tasks.map((t, i) => (
                  <div key={i} className="space-y-1.5"><div className="flex gap-2">
                    <input
                      required
                      value={t.title}
                      onChange={(e) => setTask(tasks, setTasks, i, "title", e.target.value)}
                      placeholder={`Úkol ${i + 1}`}
                      className={inputCls}
                    />
                    <input
                      required
                      type="number"
                      min={1}
                      max={100}
                      value={t.reward}
                      onChange={(e) => setTask(tasks, setTasks, i, "reward", e.target.value)}
                      aria-label={`Lezíky za úkol ${i + 1}`}
                      className={`${inputCls} w-20 text-center`}
                    />
                    <button
                      type="button"
                      onClick={() => removeRow(tasks, setTasks, i)}
                      aria-label={`Odebrat úkol ${i + 1}`}
                      className="shrink-0 rounded-xl border border-input bg-card px-3 text-sm font-bold text-destructive"
                    >
                      ✕
                    </button>
                  </div>{levelPicker(tasks, setTasks, i)}</div>
                ))}
                <button
                  type="button"
                  onClick={() => addRow(tasks, setTasks)}
                  className="w-full rounded-xl border border-dashed border-primary/40 py-2 text-[12px] font-bold text-primary"
                >
                  ＋ Přidat úkol
                </button>
                <p className="text-[11px] text-muted-foreground">
                  Číslo vpravo = počet lezíků za úkol. Pod úkolem vyberte kategorie (nic = pro všechny). Dosavadní výzva skončí, získané lezíky dětem zůstanou.
                </p>
                <button
                  disabled={saving}
                  type="submit"
                  className="w-full rounded-xl bg-primary py-2.5 text-sm font-semibold text-primary-foreground disabled:opacity-60"
                >
                  Vyhlásit výzvu
                </button>
              </form>
            )}
          </>
        )}
      </div>
    </AppShell>
  );
}
