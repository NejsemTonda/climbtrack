import { createFileRoute, Outlet } from "@tanstack/react-router";

// Aplikace je bez přihlášení — kdo má odkaz, je rovnou uvnitř.
export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  component: () => <Outlet />,
});
