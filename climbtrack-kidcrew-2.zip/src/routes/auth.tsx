import { createFileRoute, redirect } from "@tanstack/react-router";

// Přihlášení bylo zrušeno — staré odkazy vedou rovnou na hlavní stránku.
export const Route = createFileRoute("/auth")({
  beforeLoad: () => {
    throw redirect({ to: "/" });
  },
});
