import { describe, expect, it } from "vitest";

import { pointsForStyle } from "@/lib/queries";

// Body se počítají z stylu přelezu: 2 za top rope, 4 za vylezenou cestu na prvním.
describe("Body za vylezené cesty", () => {
  it("dá 2 body za cestu vylezenou na top rope", () => {
    expect(pointsForStyle("top rope")).toBe(2);
  });

  it("dá 4 body za vylezenou cestu na prvním", () => {
    expect(pointsForStyle("na prvním")).toBe(4);
  });

  it("nepočítá body ani pro styl bez bodů, ani pro chybějící styl", () => {
    expect(pointsForStyle("přelez")).toBe(0);
    expect(pointsForStyle(null)).toBe(0);
  });
});

import { totalPoints } from "@/lib/queries";
describe("totalPoints", () => {
  it("stejná cesta top rope dvakrát = 2 body", () => {
    const c = { route_color: "modrá", chain_number: 5 };
    expect(totalPoints([{ ...c, style: "top rope" }, { ...c, style: "top rope" }])).toBe(2);
  });
  it("top rope a pak na prvním na stejné cestě = jen 4 body", () => {
    const c = { route_color: "modrá", chain_number: 5 };
    expect(totalPoints([{ ...c, style: "top rope" }, { ...c, style: "na prvním" }])).toBe(4);
  });
});
