<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Boulder photos use a dedicated private Storage bucket with signed read URLs; bucket-scoped policies match the app's no-login access.
- Non-rope climbs keep a permanent catalog identifier without a foreign key so same-color boulders stay distinct and removing catalog items preserves point identity.
