ALTER TABLE public.routes ADD COLUMN kind text NOT NULL DEFAULT 'cesta';
ALTER TABLE public.routes ADD COLUMN points smallint;
ALTER TABLE public.routes ADD CONSTRAINT routes_kind_check CHECK (kind IN ('cesta','traverz','boulder'));
ALTER TABLE public.routes DROP CONSTRAINT IF EXISTS routes_color_chain_number_key;
ALTER TABLE public.routes ADD CONSTRAINT routes_kind_color_chain_key UNIQUE (kind, color, chain_number);
ALTER TABLE public.climbs ADD COLUMN route_kind text NOT NULL DEFAULT 'cesta';
ALTER TABLE public.climbs ADD COLUMN points smallint;
ALTER TABLE public.climbs DROP CONSTRAINT IF EXISTS climbs_style_check;
ALTER TABLE public.climbs ADD CONSTRAINT climbs_style_check CHECK (style = ANY (ARRAY['top rope','na prvním','přelez','OS','flash','hotovo','top']));