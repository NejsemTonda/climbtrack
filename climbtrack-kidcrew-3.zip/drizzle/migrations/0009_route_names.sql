ALTER TABLE public.routes ADD COLUMN name text NOT NULL DEFAULT '';
ALTER TABLE public.routes DROP CONSTRAINT IF EXISTS routes_kind_color_chain_key;
ALTER TABLE public.routes ADD CONSTRAINT routes_kind_color_chain_name_key UNIQUE (kind, color, chain_number, name);