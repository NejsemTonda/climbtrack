ALTER TABLE public.routes ADD COLUMN photo_path text;
ALTER TABLE public.climbs ADD COLUMN catalog_route_id uuid;
UPDATE public.climbs SET catalog_route_id = route_id WHERE route_kind <> 'cesta' AND route_id IS NOT NULL;
ALTER TABLE public.routes DROP CONSTRAINT IF EXISTS routes_kind_color_chain_name_key;
CREATE UNIQUE INDEX routes_non_boulder_identity ON public.routes (kind, color, chain_number, name) WHERE kind <> 'boulder';
CREATE POLICY "Boulder photos read" ON storage.objects FOR SELECT TO anon, authenticated USING (bucket_id = 'boulder-photos');
CREATE POLICY "Boulder photos upload" ON storage.objects FOR INSERT TO anon, authenticated WITH CHECK (bucket_id = 'boulder-photos' AND lower(storage.extension(name)) IN ('jpg', 'jpeg', 'png', 'webp'));
CREATE POLICY "Boulder photos remove" ON storage.objects FOR DELETE TO anon, authenticated USING (bucket_id = 'boulder-photos');