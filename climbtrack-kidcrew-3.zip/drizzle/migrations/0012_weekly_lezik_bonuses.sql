CREATE TABLE public.lezik_weekly_bonuses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id uuid NOT NULL REFERENCES public.children(id) ON DELETE CASCADE,
  week_start date NOT NULL,
  reward smallint NOT NULL CHECK (reward BETWEEN 1 AND 4),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT lezik_weekly_bonuses_child_week_unique UNIQUE (child_id, week_start)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.lezik_weekly_bonuses TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.lezik_weekly_bonuses TO authenticated;
GRANT ALL ON public.lezik_weekly_bonuses TO service_role;

ALTER TABLE public.lezik_weekly_bonuses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public access" ON public.lezik_weekly_bonuses
  FOR ALL TO anon, authenticated
  USING (true) WITH CHECK (true);

CREATE INDEX lezik_weekly_bonuses_week_idx ON public.lezik_weekly_bonuses (week_start, child_id);