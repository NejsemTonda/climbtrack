import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";

export function BoulderPhoto({ url, label }: { url: string; label: string }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button type="button" variant="ghost" className="h-14 w-14 shrink-0 overflow-hidden p-0" onClick={() => setOpen(true)} aria-label={`Zvětšit fotku: ${label}`}>
        <img src={url} alt={`Boulder ${label}`} className="h-full w-full rounded-md object-cover" />
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent aria-describedby={undefined} className="max-w-2xl">
          <DialogTitle>Fotka boulderu · {label}</DialogTitle>
          <img src={url} alt={`Boulder ${label}`} className="max-h-[75dvh] w-full object-contain" />
        </DialogContent>
      </Dialog>
    </>
  );
}