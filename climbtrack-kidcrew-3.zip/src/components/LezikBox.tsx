import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { childLezikQuery, currentChallengeQuery, lezikLabel } from "@/lib/queries";
import { WeeklyBonus } from "@/components/WeeklyBonus";

export const LEZIK_MAX_PER_CHALLENGE = 2;

export function LezikBox({ childId, level }: { childId: string; level?: string | null }) {
  const queryClient = useQueryClient();
  const { data: challenge } = useQuery(currentChallengeQuery());
  const { data: done = [] } = useQuery(childLezikQuery(childId));
  const total = done.reduce((s, d) => s + d.reward, 0);
  const lvl = level ?? "začátečník";
  const tasks = challenge?.lezik_tasks ?? [];
  const forLevel = (t: { levels?: string[] | null }) => !t.levels?.length || t.levels.includes(lvl);
  const doneInChallenge = (challenge?.lezik_tasks ?? []).filter((t) => done.some((d) => d.task_id === t.id)).length;
  const full = doneInChallenge >= LEZIK_MAX_PER_CHALLENGE;

  async function toggle(task: { id: string; title: string; reward: number }) {
    const existing = done.find((d) => d.task_id === task.id);
    if (!existing && full) {
      toast.error(`V této výzvě lze splnit jen ${LEZIK_MAX_PER_CHALLENGE} úkoly`);
      return;
    }
    const { error } = existing
      ? await supabase.from("lezik_completions").delete().eq("id", existing.id)
      : await supabase
          .from("lezik_completions")
          .insert({ child_id: childId, task_id: task.id, task_title: task.title, reward: task.reward });
    if (error) {
      toast.error("Nepodařilo se uložit");
      return;
    }
    toast.success(existing ? "Splnění zrušeno" : `+${task.reward} ${lezikLabel(task.reward)}`);
    await queryClient.invalidateQueries({ queryKey: ["lezik"] });
  }

  return (
    <div className="glass-tint-lezik mt-3 p-4">
      <div className="flex items-center justify-between">
        <p className="flex items-center gap-2 text-[15px] font-bold tracking-tight">
          <span className="grid size-6 place-items-center rounded-lg bg-amber/20 text-[13px] text-amber">
            ◎
          </span>
          Lezík
        </p>
        <span className="rounded-full bg-amber/20 px-2.5 py-1 text-[12px] font-extrabold text-amber">
          {total} {lezikLabel(total)}
        </span>
      </div>
      {challenge && tasks.length > 0 && (
        <p className="mt-1 text-[11px] font-semibold text-muted-foreground">
          Splněno {doneInChallenge} z {LEZIK_MAX_PER_CHALLENGE} povolených úkolů
        </p>
      )}
      {!challenge || tasks.length === 0 ? (
        <p className="mt-2 text-[12px] text-muted-foreground">Žádná aktuální výzva.</p>
      ) : (
        <div className="mt-2.5 space-y-2">
          {tasks.map((t) => {
            const isDone = done.some((d) => d.task_id === t.id);
            const wrongLevel = !isDone && !forLevel(t);
            const locked = !isDone && (full || wrongLevel);
            const reason = wrongLevel
              ? `Jen pro: ${t.levels?.join(", ")}`
              : locked
                ? `Limit ${LEZIK_MAX_PER_CHALLENGE} úkolů splněn`
                : null;
            return (
              <button
                key={t.id}
                onClick={() => toggle(t)}
                disabled={locked}
                className={`flex w-full items-center gap-3 rounded-xl border px-3 py-2.5 text-left transition-colors ${
                  isDone
                    ? "border-forest/40 bg-forest/10"
                    : locked
                      ? "cursor-not-allowed border-dashed border-border bg-muted"
                      : "border-amber/30 bg-card"
                }`}
              >
                <span
                  className={`grid size-6 shrink-0 place-items-center rounded-full border text-[12px] font-bold ${
                    isDone
                      ? "border-forest bg-forest text-primary-foreground"
                      : locked
                        ? "border-border text-muted-foreground"
                        : "border-amber/50"
                  }`}
                >
                  {isDone ? "✓" : locked ? "🔒" : ""}
                </span>
                <span className="flex-1">
                  <span className={`block text-[13px] font-semibold ${locked ? "text-muted-foreground" : ""}`}>
                    {t.title}
                  </span>
                  {reason && <span className="block text-[11px] text-muted-foreground">{reason}</span>}
                </span>
                <span className={`text-[11px] font-bold ${locked ? "text-muted-foreground" : "text-amber"}`}>
                  {t.reward} {lezikLabel(t.reward)}
                </span>
              </button>
            );
          })}
        </div>
      )}
      <WeeklyBonus childId={childId} />
    </div>
  );
}
