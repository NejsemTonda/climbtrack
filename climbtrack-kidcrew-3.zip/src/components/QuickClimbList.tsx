import { useState } from "react";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { routesQuery, colorCls, routeLabel, ROUTE_KINDS, TRAVERSE_POINTS, type RouteKind } from "@/lib/queries";
import { BoulderPhoto } from "@/components/BoulderPhoto";

type Climb = { style: string | null; route_color: string | null; chain_number: number | null; route_kind?: string | null; route_name?: string | null; route_id?: string | null; catalog_route_id?: string | null };
type Style = "top rope" | "na prvním" | "hotovo" | "top";
const styleLabel = (s: Style) => (s === "na prvním" ? "Lead" : s === "top rope" ? "Top Rope" : s === "hotovo" ? "Hotovo" : "Top");

export function QuickClimbList({
  childId,
  groupId,
  climbs,
}: {
  childId: string;
  groupId: string;
  climbs: Climb[];
}) {
  const queryClient = useQueryClient();
  const { data: allRoutes } = useSuspenseQuery(routesQuery());
  const [kind, setKind] = useState<RouteKind>("cesta");
  const routes = allRoutes.filter((r) => (r.kind ?? "cesta") === kind);
  const [busy, setBusy] = useState<string | null>(null);

  const done = new Map<string, Set<string>>();
  for (const c of climbs) {
    if (!c.catalog_route_id && !c.route_id && !c.route_name && !c.route_color) continue;
    if ((c.route_kind ?? "cesta") !== kind) continue;
    const k = kind !== "cesta" && (c.catalog_route_id || c.route_id) ? `id:${c.catalog_route_id || c.route_id}` : keyOf(c.route_color, c.chain_number, c.route_name);
    if (!done.has(k)) done.set(k, new Set());
    done.get(k)?.add(c.style ?? "");
  }
  function keyOf(color: string | null, chain: number | null, name: string | null | undefined) {
    return `${color ?? ""}#${chain ?? 0}#${name ?? ""}`;
  }
  const rk = (r: (typeof routes)[number]) => kind !== "cesta" ? `id:${r.id}` : keyOf(r.color, r.chain_number, r.name || null);
  const rank = (k: string) => {
    const s = done.get(k);
    if (s?.has("na prvním") || s?.has("hotovo") || s?.has("top")) return 2;
    if (s?.has("top rope")) return 1;
    return 0;
  };
  const sorted = [...routes].sort(
    (a, b) => rank(rk(a)) - rank(rk(b)),
  );

  async function log(route: (typeof routes)[number], style: Style) {
    setBusy(`${route.id}:${style}`);
    const {
      data: { user },
    } = await supabase.auth.getUser();
    const { error } = await supabase.from("climbs").insert({
      child_id: childId,
      group_id: groupId,
      logged_by: user?.id ?? null,
      route_id: route.id,
      catalog_route_id: kind !== "cesta" ? route.id : null,
      route_color: route.color,
      chain_number: route.chain_number,
      grade: "",
      style,
      route_kind: kind,
      route_name: route.name || null,
      points: kind === "boulder" ? (route.points ?? 0) : kind === "traverz" ? TRAVERSE_POINTS : null,
    });
    setBusy(null);
    if (error) {
      toast.error("Záznam se nepodařilo uložit");
      return;
    }
    toast.success(`${routeLabel(route)} · ${styleLabel(style)} zapsáno`);
    await queryClient.invalidateQueries();
  }

  async function undo(route: (typeof routes)[number], style: Style) {
    if (!confirm(`Zrušit zápis ${routeLabel(route)} · ${styleLabel(style)}?`)) return;
    setBusy(`${route.id}:${style}`);
    let q = supabase
      .from("climbs")
      .delete()
      .eq("child_id", childId)
      .eq("route_color", route.color)
      .eq("chain_number", route.chain_number)
      .eq("style", style)
      .eq("route_kind", kind);
    q = route.name ? q.eq("route_name", route.name) : q.is("route_name", null);
    if (kind !== "cesta") q = q.eq("route_id", route.id);
    const { error } = await q;
    setBusy(null);
    if (error) {
      toast.error("Zápis se nepodařilo zrušit");
      return;
    }
    toast.success("Zápis zrušen");
    await queryClient.invalidateQueries();
  }

  const btn = (active: boolean, disabled: boolean) =>
    `rounded-lg px-3 py-2 text-[12px] font-bold transition-transform active:scale-95 ${
      active
        ? "bg-zapis text-ink-foreground"
        : disabled
          ? "bg-secondary/50 text-muted-foreground/50"
          : "border border-input bg-card text-foreground"
    }`;

  return (
    <div className="mt-3">
      <div className="mb-2 flex gap-1.5">
        {ROUTE_KINDS.map((k) => (
          <button
            key={k.id}
            onClick={() => setKind(k.id)}
            className={`flex-1 rounded-xl px-2 py-2 text-[13px] font-extrabold uppercase tracking-wide transition-colors ${
              kind === k.id ? "bg-primary text-primary-foreground shadow-sm" : "border border-input bg-card text-foreground/70"
            }`}
          >
            {k.label}
          </button>
        ))}
      </div>
      {routes.length === 0 && (
        <p className="glass-card p-4 text-center text-sm text-muted-foreground">
          Zatím nic — přidejte je na stránce Cesty.
        </p>
      )}
      <div className="space-y-1.5">
        {sorted.map((r) => {
          const k = rk(r);
          const lvl = rank(k);
          return (
            <div
              key={r.id}
              className={`glass-chip flex items-center gap-2.5 px-3 py-2 ${lvl === 2 ? "opacity-60" : ""}`}
            >
              {r.color ? (
                <span className={`size-4 shrink-0 rounded-full ${colorCls(r.color)}`} />
              ) : (
                <span className="size-4 shrink-0" />
              )}
              {kind === "boulder" && r.photo_url && <BoulderPhoto url={r.photo_url} label={r.color || "Boulder"} />}
              <div className="min-w-0 flex-1">
                <p className="text-[14px] font-bold">
                  {r.name ? (
                    <>
                      {r.name}
                      {(r.color || r.chain_number > 0) && (
                        <span className="text-muted-foreground">
                          {" "}· {[r.color, r.chain_number > 0 ? r.chain_number : ""].filter(Boolean).join(" ")}
                        </span>
                      )}
                    </>
                  ) : (
                    <>
                      {r.color || (kind === "boulder" ? "Boulder" : "Traverz")} {kind === "cesta" && <span className="text-muted-foreground">· {r.chain_number}</span>}
                    </>
                  )}
                </p>
                {kind !== "cesta" && r.description && (
                  <p className="mt-0.5 line-clamp-2 text-[11px] font-medium text-muted-foreground">{r.description}</p>
                )}
              </div>
              {kind === "cesta" ? (
                <>
                  <button
                    disabled={lvl === 2 || busy !== null}
                    onClick={() => (lvl === 1 ? undo(r, "top rope") : log(r, "top rope"))}
                    className={btn(lvl === 1, lvl >= 1)}
                  >
                    {lvl >= 1 ? "✓ " : ""}Top Rope
                  </button>
                  <button
                    disabled={busy !== null}
                    onClick={() => (lvl === 2 ? undo(r, "na prvním") : log(r, "na prvním"))}
                    className={btn(lvl === 2, false)}
                  >
                    {lvl === 2 ? "✓ " : ""}Lead
                  </button>
                </>
              ) : (
                <>
                  <span className="text-[11px] font-bold text-muted-foreground">
                    {kind === "traverz" ? TRAVERSE_POINTS : (r.points ?? 0)} b
                  </span>
                  <button
                    disabled={busy !== null}
                    onClick={() => {
                      const st: Style = kind === "traverz" ? "hotovo" : "top";
                      return lvl === 2 ? undo(r, st) : log(r, st);
                    }}
                    className={btn(lvl === 2, false)}
                  >
                    {lvl === 2 ? "✓ " : ""}
                    {kind === "traverz" ? "Hotovo" : "Top"}
                  </button>
                </>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
