import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Check } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { weeklyBonusQuery } from "@/lib/queries";
import { mondayOfWeek, WEEKLY_BONUS_MAX } from "@/lib/weekly-bonus";


export function WeeklyBonus({ childId }: { childId: string }) {
  const queryClient = useQueryClient();
  const weekStart = mondayOfWeek();
  const { data: bonus } = useQuery(weeklyBonusQuery(childId, weekStart));
  const [selectedText, setSelectedText] = useState("1");
  const selected = Math.min(WEEKLY_BONUS_MAX, Math.max(1, Math.round(Number(selectedText)) || 1));
  const [saving, setSaving] = useState(false);
  const done = (bonus?.reward ?? 0) > 0;
  const reward = done ? bonus!.reward : selected;

  async function toggle() {
    if (saving) return;
    if (done && !confirm("Zrušit tento týdenní bonus?")) return;
    setSaving(true);
    const { error } = done
      ? await supabase.from("lezik_weekly_bonuses").delete().eq("child_id", childId).eq("week_start", weekStart)
      : await supabase.from("lezik_weekly_bonuses").upsert(
          { child_id: childId, week_start: weekStart, reward: selected, updated_at: new Date().toISOString() },
          { onConflict: "child_id,week_start" },
        );
    setSaving(false);
    if (error) {
      toast.error("Bonus se nepodařilo uložit");
      return;
    }
    await queryClient.invalidateQueries({ queryKey: ["lezik"] });
  }

  return (
    <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-amber/20 pt-3">
      <p className="text-[13px] font-extrabold tracking-wide">BONUS</p>
      <input
        type="number"
        inputMode="numeric"
        min={1}
        max={WEEKLY_BONUS_MAX}
        aria-label="Počet bonusových lezíků"
        value={done ? reward : selectedText}
        disabled={done || saving}
        onChange={(e) => setSelectedText(e.target.value)}
        className="ml-auto h-9 w-16 rounded-xl border border-input bg-card px-2 text-center text-sm font-bold disabled:opacity-60"
      />
      <button
        type="button"
        disabled={saving}
        onClick={toggle}
        className={`flex items-center gap-1 rounded-full px-3 py-1.5 text-[13px] font-bold transition ${
          done ? "bg-amber text-primary-foreground" : "border border-amber text-amber bg-card"
        }`}
      >
        {done && <Check className="size-4" />}
        Hotovo
      </button>
    </div>
  );
}
