export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      children: {
        Row: {
          birth_year: number | null
          climbing_years: number | null
          created_at: string
          first_name: string
          gender: string
          group_id: string
          id: string
          last_name: string
          level: string | null
        }
        Insert: {
          birth_year?: number | null
          climbing_years?: number | null
          created_at?: string
          first_name: string
          gender?: string
          group_id: string
          id?: string
          last_name?: string
          level?: string | null
        }
        Update: {
          birth_year?: number | null
          climbing_years?: number | null
          created_at?: string
          first_name?: string
          gender?: string
          group_id?: string
          id?: string
          last_name?: string
          level?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "children_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "groups"
            referencedColumns: ["id"]
          },
        ]
      }
      climbs: {
        Row: {
          catalog_route_id: string | null
          chain_number: number | null
          child_id: string
          climbed_at: string
          created_at: string
          falls: number
          grade: string
          group_id: string
          id: string
          logged_by: string | null
          note: string | null
          points: number | null
          route_color: string | null
          route_id: string | null
          route_kind: string
          route_name: string | null
          style: string
        }
        Insert: {
          catalog_route_id?: string | null
          chain_number?: number | null
          child_id: string
          climbed_at?: string
          created_at?: string
          falls?: number
          grade?: string
          group_id: string
          id?: string
          logged_by?: string | null
          note?: string | null
          points?: number | null
          route_color?: string | null
          route_id?: string | null
          route_kind?: string
          route_name?: string | null
          style?: string
        }
        Update: {
          catalog_route_id?: string | null
          chain_number?: number | null
          child_id?: string
          climbed_at?: string
          created_at?: string
          falls?: number
          grade?: string
          group_id?: string
          id?: string
          logged_by?: string | null
          note?: string | null
          points?: number | null
          route_color?: string | null
          route_id?: string | null
          route_kind?: string
          route_name?: string | null
          style?: string
        }
        Relationships: [
          {
            foreignKeyName: "climbs_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "children"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "climbs_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "climbs_route_id_fkey"
            columns: ["route_id"]
            isOneToOne: false
            referencedRelation: "routes"
            referencedColumns: ["id"]
          },
        ]
      }
      groups: {
        Row: {
          created_at: string
          end_time: string
          id: string
          name: string
          start_time: string
          weekday: number
        }
        Insert: {
          created_at?: string
          end_time: string
          id?: string
          name: string
          start_time: string
          weekday: number
        }
        Update: {
          created_at?: string
          end_time?: string
          id?: string
          name?: string
          start_time?: string
          weekday?: number
        }
        Relationships: []
      }
      lezik_challenges: {
        Row: {
          created_at: string
          ends_on: string
          id: string
          starts_on: string
          title: string
        }
        Insert: {
          created_at?: string
          ends_on?: string
          id?: string
          starts_on?: string
          title?: string
        }
        Update: {
          created_at?: string
          ends_on?: string
          id?: string
          starts_on?: string
          title?: string
        }
        Relationships: []
      }
      lezik_completions: {
        Row: {
          child_id: string
          completed_at: string
          id: string
          reward: number
          task_id: string | null
          task_title: string
        }
        Insert: {
          child_id: string
          completed_at?: string
          id?: string
          reward: number
          task_id?: string | null
          task_title: string
        }
        Update: {
          child_id?: string
          completed_at?: string
          id?: string
          reward?: number
          task_id?: string | null
          task_title?: string
        }
        Relationships: [
          {
            foreignKeyName: "lezik_completions_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "children"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lezik_completions_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "lezik_tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      lezik_tasks: {
        Row: {
          challenge_id: string
          created_at: string
          id: string
          levels: string[]
          position: number
          reward: number
          title: string
        }
        Insert: {
          challenge_id: string
          created_at?: string
          id?: string
          levels?: string[]
          position?: number
          reward?: number
          title: string
        }
        Update: {
          challenge_id?: string
          created_at?: string
          id?: string
          levels?: string[]
          position?: number
          reward?: number
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "lezik_tasks_challenge_id_fkey"
            columns: ["challenge_id"]
            isOneToOne: false
            referencedRelation: "lezik_challenges"
            referencedColumns: ["id"]
          },
        ]
      }
      lezik_weekly_bonuses: {
        Row: {
          child_id: string
          created_at: string
          id: string
          reward: number
          updated_at: string
          week_start: string
        }
        Insert: {
          child_id: string
          created_at?: string
          id?: string
          reward: number
          updated_at?: string
          week_start: string
        }
        Update: {
          child_id?: string
          created_at?: string
          id?: string
          reward?: number
          updated_at?: string
          week_start?: string
        }
        Relationships: [
          {
            foreignKeyName: "lezik_weekly_bonuses_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "children"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          display_name: string | null
          id: string
        }
        Insert: {
          created_at?: string
          display_name?: string | null
          id: string
        }
        Update: {
          created_at?: string
          display_name?: string | null
          id?: string
        }
        Relationships: []
      }
      routes: {
        Row: {
          chain_number: number
          color: string
          created_at: string
          description: string | null
          id: string
          kind: string
          name: string
          photo_path: string | null
          points: number | null
        }
        Insert: {
          chain_number: number
          color: string
          created_at?: string
          description?: string | null
          id?: string
          kind?: string
          name?: string
          photo_path?: string | null
          points?: number | null
        }
        Update: {
          chain_number?: number
          color?: string
          created_at?: string
          description?: string | null
          id?: string
          kind?: string
          name?: string
          photo_path?: string | null
          points?: number | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
