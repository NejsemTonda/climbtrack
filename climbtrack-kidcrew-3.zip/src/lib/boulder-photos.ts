export const BOULDER_PHOTO_BUCKET = "boulder-photos";
export const BOULDER_PHOTO_MAX_BYTES = 10 * 1024 * 1024;
export const BOULDER_PHOTO_TYPES: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
};

export function photoError(file: { type: string; size: number }) {
  if (!BOULDER_PHOTO_TYPES[file.type]) return "Vyberte fotku JPG, PNG nebo WebP";
  if (file.size > BOULDER_PHOTO_MAX_BYTES) return "Fotka může mít nejvýše 10 MB";
  return null;
}