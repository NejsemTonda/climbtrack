export const WEEKLY_BONUS_MAX = 4;

function localDateString(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

/** Pondělí kalendářního týdne, do kterého datum patří. */
export function mondayOfWeek(date = new Date()) {
  const monday = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const daysSinceMonday = (monday.getDay() + 6) % 7;
  monday.setDate(monday.getDate() - daysSinceMonday);
  return localDateString(monday);
}

/** Bonus lze po jednom lezíku přidat i odebrat, vždy jen v rozsahu 0–4. */
export function changeWeeklyBonus(current: number, delta: 1 | -1) {
  return Math.min(WEEKLY_BONUS_MAX, Math.max(0, current + delta));
}
