import { createFileRoute } from "@tanstack/react-router";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { Camera, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { BoulderPhoto } from "@/components/BoulderPhoto";
import { BOULDER_PHOTO_BUCKET, BOULDER_PHOTO_TYPES, photoError } from "@/lib/boulder-photos";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { routesQuery, ROUTE_COLORS, colorCls, routeLabel, ROUTE_KINDS, TRAVERSE_POINTS, type RouteKind } from "@/lib/queries";

export const Route = createFileRoute("/_authenticated/cesty")({
  head: () => ({
    meta: [
      { title: "Cesty na stěně — HC4" },
      { name: "description", content: "Seznam cest na lezecké stěně podle barvy a čísla řetězu." },
      { property: "og:title", content: "Cesty na stěně — HC4" },
      { property: "og:description", content: "Správa cest na stěně pro instruktory." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RoutesPage,
});

function RoutesPage() {
  const queryClient = useQueryClient();
  const { data: allRoutes } = useSuspenseQuery(routesQuery());
  const [kind, setKind] = useState<RouteKind>("cesta");
  const [pts, setPts] = useState("");
  const routes = allRoutes.filter((r) => (r.kind ?? "cesta") === kind);
  const [color, setColor] = useState("");
  const [chain, setChain] = useState("");
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");
  const [saving, setSaving] = useState(false);
  const [photo, setPhoto] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  const photoInput = useRef<HTMLInputElement>(null);
  useEffect(() => {
    if (!photo) { setPreview(""); return; }
    const url = URL.createObjectURL(photo);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [photo]);

  function clearPhoto() {
    setPhoto(null);
    if (photoInput.current) photoInput.current.value = "";
  }

  async function add(e: React.FormEvent) {
    e.preventDefault();
    const n = kind !== "cesta" ? 0 : chain === "" ? 0 : Number(chain);
    const nm = kind === "traverz" ? name.trim().slice(0, 80) : "";
    const d = kind !== "cesta" ? desc.trim().slice(0, 300) : "";
    if (kind === "traverz") {
      if (!nm && !color) {
        toast.error("Napište název nebo vyberte barvu");
        return;
      }
    } else if (kind === "cesta" && (!color || !Number.isInteger(n) || n < 1 || n > 999)) {
      toast.error("Vyberte barvu a zadejte číslo");
      return;
    }
    const p = Number(pts);
    if (kind === "boulder" && (!Number.isInteger(p) || p < 1 || p > 100)) {
      toast.error("Zadejte počet bodů za boulder");
      return;
    }
    if (kind !== "boulder" && routes.some((r) => r.color === color && r.chain_number === n && (r.name ?? "") === nm)) {
      toast.error("Toto už v seznamu je");
      return;
    }
    setSaving(true);
    let photoPath: string | null = null;
    try {
      if (kind === "boulder" && photo) {
        photoPath = `${crypto.randomUUID()}.${BOULDER_PHOTO_TYPES[photo.type]}`;
        const { error } = await supabase.storage.from(BOULDER_PHOTO_BUCKET).upload(photoPath, photo, { contentType: photo.type });
        if (error) throw error;
      }
      const { error } = await supabase.from("routes").insert({ color, chain_number: n, name: nm, kind, points: kind === "boulder" ? p : null, photo_path: photoPath, description: d || null });
      if (error) {
        if (photoPath) await supabase.storage.from(BOULDER_PHOTO_BUCKET).remove([photoPath]);
        throw error;
      }
      toast.success("Přidáno");
      setChain("");
      setName("");
      setPts("");
      setDesc("");
      clearPhoto();
      await queryClient.invalidateQueries({ queryKey: ["routes"] });
    } catch {
      toast.error("Nepodařilo se uložit položku nebo fotku. Zkuste to znovu.");
    } finally {
      setSaving(false);
    }
  }

  async function remove(id: string) {
    if (!confirm("Odebrat cestu ze seznamu? Zapsané přelezy zůstanou.")) return;
    const { error } = await supabase.from("routes").delete().eq("id", id);
    if (error) {
      toast.error("Cestu se nepodařilo odebrat");
      return;
    }
    const removed = allRoutes.find((r) => r.id === id);
    if (removed?.photo_path) await supabase.storage.from(BOULDER_PHOTO_BUCKET).remove([removed.photo_path]);
    await queryClient.invalidateQueries({ queryKey: ["routes"] });
  }

  return (
    <AppShell>
      <div className="pt-4">
        <h1 className="flex items-center gap-2 text-xl font-extrabold tracking-tight">
          <span className="grid size-7 place-items-center rounded-xl bg-cesty/12 text-[14px] text-cesty-ink">
            ⛓
          </span>
          Cesty na stěně
        </h1>
        <p className="mt-1 text-xs text-muted-foreground">
          Přidejte cesty jednou — u dětí je pak jen vyberete při zápisu.
        </p>

        <div className="mt-3 flex gap-1.5">
          {ROUTE_KINDS.map((k) => (
            <button
              key={k.id}
              type="button"
              onClick={() => setKind(k.id)}
              className={`flex-1 rounded-xl px-2 py-2 text-[13px] font-extrabold uppercase tracking-wide ${
                kind === k.id ? "bg-cesty text-ink-foreground shadow-sm" : "border border-input bg-card text-foreground/70"
              }`}
            >
              {k.label}
            </button>
          ))}
        </div>
        {kind === "traverz" && (
          <p className="mt-2 text-[11px] font-medium text-muted-foreground">Každý traverz = {TRAVERSE_POINTS} bodů.</p>
        )}

        <form onSubmit={add} className="glass-card mt-3 space-y-3 p-4">
          {kind === "traverz" && (
            <input
              value={name}
              maxLength={80}
              onChange={(e) => setName(e.target.value)}
              placeholder="Název traverzu (nepovinné)"
              className="w-full rounded-xl border border-input bg-card px-3 py-2.5 text-sm outline-none focus:border-ring"
            />
          )}
          {kind === "traverz" && (
            <div className="space-y-2">
              <p className="text-[11px] font-bold uppercase text-muted-foreground">Popis (nepovinné)</p>
              <textarea
                value={desc}
                maxLength={300}
                onChange={(e) => setDesc(e.target.value)}
                placeholder="Např. kde začít, kam traverz vede, na co si dát pozor"
                rows={3}
                className="w-full resize-none rounded-xl border border-input bg-card px-3 py-2.5 text-sm outline-none focus:border-ring"
              />
            </div>
          )}
          <p className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
            {kind !== "cesta" ? "Barva (nepovinné)" : "Barva"}
          </p>
          <div className="flex flex-wrap gap-2">
            {ROUTE_COLORS.map((c) => (
              <button
                key={c.id}
                type="button"
                title={c.id}
                onClick={() => setColor(kind !== "cesta" && color === c.id ? "" : c.id)}
                className={`size-8 rounded-full ${c.cls} ${color === c.id ? "ring-2 ring-ring ring-offset-2" : ""}`}
              />
            ))}
          </div>
          {color && <p className="text-[11px] font-bold text-cesty-ink">Barva: {color}</p>}
          {kind === "boulder" && (
            <div className="space-y-2">
              <p className="text-[11px] font-bold uppercase text-muted-foreground">Fotka (nepovinné)</p>
              <input ref={photoInput} type="file" accept="image/jpeg,image/png,image/webp" aria-label="Fotka boulderu" className="hidden" onChange={(e) => {
                const file = e.target.files?.[0];
                if (!file) return;
                const error = photoError(file);
                if (error) { toast.error(error); e.target.value = ""; return; }
                setPhoto(file);
              }} />
              <div className="flex items-center gap-2">
                <Button type="button" variant="outline" disabled={saving} onClick={() => photoInput.current?.click()}><Camera />{photo ? "Změnit fotku" : "Nahrát fotku"}</Button>
                {photo && <Button type="button" variant="ghost" size="icon" aria-label="Odebrat vybranou fotku" onClick={clearPhoto}><X /></Button>}
              </div>
              {preview && <img src={preview} alt="Vybraná fotka boulderu" className="max-h-56 w-full rounded-md object-contain" />}
              <p className="text-[11px] font-bold uppercase text-muted-foreground">Popis (nepovinné)</p>
              <textarea
                value={desc}
                maxLength={300}
                onChange={(e) => setDesc(e.target.value)}
                placeholder="Např. jak je postavený, kde začít, na co si dát pozor"
                rows={3}
                className="w-full resize-none rounded-xl border border-input bg-card px-3 py-2.5 text-sm outline-none focus:border-ring"
              />
            </div>
          )}
          <div className="flex gap-2">
            {kind === "cesta" && (
              <input
                type="number"
                inputMode="numeric"
                min={1}
                max={999}
                value={chain}
                onChange={(e) => setChain(e.target.value)}
                placeholder="Číslo řetězu"
                className="w-full rounded-xl border border-input bg-card px-3 py-2.5 text-sm outline-none focus:border-ring"
              />
            )}
            {kind === "boulder" && (
              <input
                type="number"
                inputMode="numeric"
                min={1}
                max={100}
                value={pts}
                onChange={(e) => setPts(e.target.value)}
                placeholder="Body"
                className="w-24 rounded-xl border border-input bg-card px-3 py-2.5 text-sm outline-none focus:border-ring"
              />
            )}
            <button
              type="submit"
              disabled={saving}
              className="shrink-0 rounded-xl bg-cesty px-5 text-sm font-semibold text-ink-foreground shadow-md shadow-cesty/30 disabled:opacity-60"
            >
              Přidat
            </button>
          </div>
        </form>

        <h2 className="mb-2.5 mt-6 flex items-center gap-2 text-[15px] font-bold tracking-tight">
          <span className="grid size-6 place-items-center rounded-lg bg-cesty/12 text-[12px] text-cesty-ink">
            ⛓
          </span>
          {ROUTE_KINDS.find((k) => k.id === kind)?.label} ({routes.length})
        </h2>
        <div className="space-y-2">
          {routes.length === 0 && (
            <p className="glass-card p-4 text-center text-sm text-muted-foreground">Zatím nic.</p>
          )}
          {routes.map((r) => (
            <div key={r.id} className="glass-chip flex items-center gap-3 px-3.5 py-2.5">
              {kind === "boulder" && r.photo_url && <BoulderPhoto url={r.photo_url} label={r.color || "Boulder"} />}
              {r.color ? (
                <span className={`size-5 shrink-0 rounded-full ${colorCls(r.color)}`} />
              ) : (
                <span className="size-5 shrink-0" />
              )}
              <div className="min-w-0 flex-1">
                <p className="text-[13px] font-semibold">
                  {kind === "traverz" ? routeLabel(r) : kind === "boulder" ? r.color || "Boulder" : `Řetěz ${r.chain_number} · ${r.color}`}
                  {kind === "boulder" && <span className="text-muted-foreground"> · {r.points ?? 0} b</span>}
                </p>
                {kind !== "cesta" && r.description && (
                  <p className="mt-0.5 line-clamp-2 text-[11px] font-medium text-muted-foreground">{r.description}</p>
                )}
              </div>
              <Button variant="ghost" size="sm" onClick={() => remove(r.id)} className="text-xs font-semibold text-destructive">
                Odebrat
              </Button>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
