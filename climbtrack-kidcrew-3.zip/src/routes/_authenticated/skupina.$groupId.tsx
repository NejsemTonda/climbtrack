import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { AddClimbDialog } from "@/components/AddClimbDialog";
import { ChildAvatar, GenderPicker, LevelChip } from "@/components/ChildAvatar";
import { supabase } from "@/integrations/supabase/client";
import { genderFromName } from "@/lib/gender";
import {
  groupsQuery,
  childrenQuery,
  groupClimbsQuery,
  allLezikQuery,
  formatTime,
  levelForYears,
  colorCls,
  pointsForClimb,
  totalPoints,
  slotOf,
  styleMeta,
  WEEKDAYS_CS,
} from "@/lib/queries";

export const Route = createFileRoute("/_authenticated/skupina/$groupId")({
  head: () => ({
    meta: [
      { title: "Kroužek — HC4" },
      { name: "description", content: "Detail kroužku, seznam dětí a záznamy vylezených cest." },
      { property: "og:title", content: "Kroužek — HC4" },
      { property: "og:description", content: "Detail lezeckého kroužku a evidence lezení." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: GroupDetail,
});

function GroupDetail() {
  const { groupId } = Route.useParams();
  const queryClient = useQueryClient();
  const { data: groups } = useSuspenseQuery(groupsQuery());
  const { data: children } = useSuspenseQuery(childrenQuery(groupId));
  const { data: climbs } = useSuspenseQuery(groupClimbsQuery(groupId));
  const { data: lezik } = useSuspenseQuery(allLezikQuery());
  const lezikMap = new Map<string, number>();
  for (const l of lezik) lezikMap.set(l.child_id, (lezikMap.get(l.child_id) ?? 0) + l.reward);
  const [showAddClimb, setShowAddClimb] = useState(false);
  const [showAddChild, setShowAddChild] = useState(false);
  const [firstName, setFirstName] = useState("");
  const [birthYear, setBirthYear] = useState("");
  const [climbingYears, setClimbingYears] = useState("");
  const [gender, setGender] = useState("kluk");
  const [genderTouched, setGenderTouched] = useState(false);

  const group = groups.find((g) => g.id === groupId);
  if (!group) return <AppShell><p className="pt-8 text-center text-muted-foreground">Kroužek nenalezen.</p></AppShell>;

  const slot = slotOf(group.start_time);

  async function addChild(e: React.FormEvent) {
    e.preventDefault();
    const years = climbingYears === "" ? null : Number(climbingYears);
    const { error } = await supabase.from("children").insert({
      group_id: groupId,
      first_name: firstName,
      gender,
      
      birth_year: birthYear === "" ? null : Number(birthYear),
      climbing_years: years,
      level: levelForYears(years),
    });
    if (error) {
      toast.error("Dítě se nepodařilo přidat");
      return;
    }
    toast.success("Dítě přidáno");
    setFirstName("");
    
    setBirthYear("");
    setClimbingYears("");
    setShowAddChild(false);
    await queryClient.invalidateQueries();
  }

  return (
    <AppShell>
      <div className="pt-4">
        <Link to="/" className="text-xs font-semibold text-muted-foreground">
          ← Zpět na přehled
        </Link>
        <div className={`${slot.tint} mt-2 p-4`}>
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
              {WEEKDAYS_CS[group.weekday]}
            </span>
            <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${slot.chip}`}>
              {formatTime(group.start_time)}–{formatTime(group.end_time)}
            </span>
          </div>
          <h1 className="mt-1 text-xl font-extrabold tracking-tight">
            Kroužek {formatTime(group.start_time)}–{formatTime(group.end_time)}
          </h1>
          <p className="mt-1 text-xs font-medium text-muted-foreground">
            {children.length} dětí · {climbs.length} záznamů
          </p>
        </div>

        <div className="mb-2.5 mt-6 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-[15px] font-bold tracking-tight">
            <span className={`grid size-6 place-items-center rounded-lg text-[12px] ${slot.chip}`}>
              ◍
            </span>
            Děti v kroužku
          </h2>
          <button
            onClick={() => setShowAddChild(!showAddChild)}
            className="text-xs font-semibold text-krouzky"
          >
            {showAddChild ? "Zavřít" : "＋ Přidat dítě"}
          </button>
        </div>

        {showAddChild && (
          <form onSubmit={addChild} className="glass-card mb-3 space-y-2 p-4">
            <GenderPicker
              value={gender}
              onChange={(v) => {
                setGender(v);
                setGenderTouched(true);
              }}
            />
            <input
              required
              value={firstName}
              onChange={(e) => {
                setFirstName(e.target.value);
                if (!genderTouched) {
                  const g = genderFromName(e.target.value);
                  if (g) setGender(g);
                }
              }}
              placeholder="Jméno"
              className="w-full rounded-xl border border-input bg-card px-3 py-2.5 text-sm outline-none focus:border-ring"
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                required
                type="number"
                min={1940}
                max={new Date().getFullYear()}
                value={birthYear}
                onChange={(e) => setBirthYear(e.target.value)}
                placeholder="Rok narození"
                className="w-full rounded-xl border border-input bg-card px-3 py-2.5 text-sm outline-none focus:border-ring"
              />
              <input
                required
                type="number"
                min={0}
                max={60}
                value={climbingYears}
                onChange={(e) => setClimbingYears(e.target.value)}
                placeholder="Kolik let leze"
                className="w-full rounded-xl border border-input bg-card px-3 py-2.5 text-sm outline-none focus:border-ring"
              />
            </div>
            {climbingYears !== "" && (
              <p className="text-[11px] font-medium text-muted-foreground">
                Úroveň: <span className="font-bold text-primary">{levelForYears(Number(climbingYears))}</span>
              </p>
            )}
            <button
              type="submit"
              className="w-full rounded-xl bg-primary py-2.5 text-sm font-semibold text-primary-foreground shadow-md shadow-primary/30"
            >
              Přidat do kroužku
            </button>
          </form>
        )}

        <div className="space-y-2">
          {children.length === 0 && (
            <p className="glass-card p-4 text-center text-sm text-muted-foreground">
              Zatím žádné děti. Přidejte první!
            </p>
          )}
          {children.map((c) => {
            const own = climbs.filter((cl) => cl.child_id === c.id);
            const points = totalPoints(own);
            return (
              <Link
                key={c.id}
                to="/dite/$childId"
                params={{ childId: c.id }}
                className="glass-chip flex items-center gap-3 px-3.5 py-3 transition-transform active:scale-[0.98]"
              >
                <ChildAvatar name={c.first_name} gender={c.gender} level={c.level} />
                <div className="flex-1">
                  <p className="text-[15px] font-extrabold tracking-tight text-foreground">
                    {c.first_name}
                  </p>
                  <div className="mt-1 flex flex-wrap items-center gap-1.5">
                    <LevelChip level={c.level} />
                    <span className="text-[11px] font-medium text-muted-foreground">
                      {c.birth_year ? `${new Date().getFullYear() - c.birth_year} let` : ""}
                    </span>
                  </div>
                </div>
                <span className="shrink-0 rounded-full bg-krouzky/10 px-2 py-0.5 text-[11px] font-bold text-krouzky">
                  {points} b
                </span>
                <span className="shrink-0 rounded-full bg-amber/20 px-2 py-0.5 text-[11px] font-bold text-amber">
                  {lezikMap.get(c.id) ?? 0} L
                </span>
                <span className="text-muted-foreground">›</span>
              </Link>
            );
          })}
        </div>

        <h2 className="mb-2.5 mt-6 flex items-center gap-2 text-[15px] font-bold tracking-tight">
          <span className="grid size-6 place-items-center rounded-lg bg-forest/12 text-[12px] text-forest">
            ⛰
          </span>
          Poslední cesty
        </h2>
        <div className="space-y-2">
          {climbs.length === 0 && (
            <p className="glass-card p-4 text-center text-sm text-muted-foreground">
              Zatím žádné záznamy.
            </p>
          )}
          {climbs.slice(0, 15).map((cl) => (
            <div key={cl.id} className="glass-chip flex items-center gap-2.5 px-3 py-2">
              <span className="grade-badge flex items-center gap-1 bg-secondary text-secondary-foreground">
                <span className={`size-2.5 rounded-full ${colorCls(cl.route_color)}`} />
                {cl.chain_number ?? cl.grade}
              </span>
              <div className="flex-1">
                <p className="text-[13px] font-medium">
                  {cl.children?.first_name}
                </p>
                <div className="mt-0.5 flex flex-wrap items-center gap-1.5">
                  <span
                    className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${styleMeta(cl.style).chip}`}
                  >
                    {styleMeta(cl.style).label}
                  </span>
                  <span className="text-[11px] font-bold text-primary">
                    {pointsForClimb(cl)} b
                  </span>
                </div>
              </div>
              <span className="text-[11px] text-muted-foreground">
                {new Date(cl.climbed_at).toLocaleDateString("cs-CZ", {
                  day: "numeric",
                  month: "numeric",
                })}
              </span>
            </div>
          ))}
        </div>
      </div>

      {showAddClimb && (
        <AddClimbDialog groupId={groupId} onClose={() => setShowAddClimb(false)} />
      )}
    </AppShell>
  );
}
