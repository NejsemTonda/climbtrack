import { describe, expect, it } from "vitest";
import { photoError } from "@/lib/boulder-photos";

describe("Fotky boulderů", () => {
  it("přijímá fotografie a odmítne soubor, který není obrázek", () => {
    expect(photoError({ type: "image/jpeg", size: 1000 })).toBeNull();
    expect(photoError({ type: "application/pdf", size: 1000 })).not.toBeNull();
  });
  it("přijímá nejvýše 10 MB", () => {
    expect(photoError({ type: "image/png", size: 10 * 1024 * 1024 })).toBeNull();
    expect(photoError({ type: "image/png", size: 10 * 1024 * 1024 + 1 })).not.toBeNull();
  });
});