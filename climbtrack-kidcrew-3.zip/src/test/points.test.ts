import { describe, expect, it } from "vitest";

import { pointsForStyle } from "@/lib/queries";

// Body se počítají z stylu přelezu: 2 za top rope, 4 za vylezenou cestu na prvním.
describe("Body za vylezené cesty", () => {
  it("dá 2 body za cestu vylezenou na top rope", () => {
    expect(pointsForStyle("top rope")).toBe(2);
  });

  it("dá 4 body za vylezenou cestu na prvním", () => {
    expect(pointsForStyle("na prvním")).toBe(4);
  });

  it("nepočítá body ani pro styl bez bodů, ani pro chybějící styl", () => {
    expect(pointsForStyle("přelez")).toBe(0);
    expect(pointsForStyle(null)).toBe(0);
  });
});

import { totalPoints } from "@/lib/queries";
describe("totalPoints", () => {
  it("stejná cesta top rope dvakrát = 2 body", () => {
    const c = { route_color: "modrá", chain_number: 5 };
    expect(totalPoints([{ ...c, style: "top rope" }, { ...c, style: "top rope" }])).toBe(2);
  });
  it("top rope a pak na prvním na stejné cestě = jen 4 body", () => {
    const c = { route_color: "modrá", chain_number: 5 };
    expect(totalPoints([{ ...c, style: "top rope" }, { ...c, style: "na prvním" }])).toBe(4);
  });
});

import { pointsForClimb } from "@/lib/queries";
describe("Traverzy a bouldery", () => {
  it("stejnobarevné bouldery bez čísla mají vlastní body a opakovaný zápis se nesčítá", () => {
    const c = { route_color: "modrá", chain_number: 0, route_kind: "boulder", style: "top" };
    expect(totalPoints([
      { ...c, catalog_route_id: "boulder-a", points: 7 },
      { ...c, catalog_route_id: "boulder-a", points: 7 },
      { ...c, catalog_route_id: "boulder-b", points: 3 },
    ])).toBe(10);
  });
  it("traverz = 5 bodů", () => {
    expect(pointsForClimb({ style: "hotovo", route_kind: "traverz" })).toBe(5);
  });
  it("boulder = body podle obtížnosti", () => {
    expect(pointsForClimb({ style: "top", route_kind: "boulder", points: 7 })).toBe(7);
  });
  it("traverz a cesta se stejnou barvou a číslem se počítají zvlášť", () => {
    const c = { route_color: "modrá", chain_number: 5 };
    expect(
      totalPoints([
        { ...c, style: "na prvním", route_kind: "cesta" },
        { ...c, style: "hotovo", route_kind: "traverz" },
      ]),
    ).toBe(9);
  });
});
