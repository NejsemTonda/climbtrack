import { describe, expect, it } from "vitest";
import { changeWeeklyBonus, mondayOfWeek, WEEKLY_BONUS_MAX } from "@/lib/weekly-bonus";

describe("Týdenní bonusové lezíky", () => {
  it("umožní nejvýš 4 lezíky na dítě za týden", () => {
    expect(WEEKLY_BONUS_MAX).toBe(4);
    expect(changeWeeklyBonus(3, 1)).toBe(4);
    expect(changeWeeklyBonus(4, 1)).toBe(4);
  });

  it("jde odkliknout až do nuly, ale ne pod ni", () => {
    expect(changeWeeklyBonus(1, -1)).toBe(0);
    expect(changeWeeklyBonus(0, -1)).toBe(0);
  });

  it("pondělí až neděle patří do stejného bonusového týdne", () => {
    expect(mondayOfWeek(new Date(2026, 10, 9, 12))).toBe("2026-11-09");
    expect(mondayOfWeek(new Date(2026, 10, 15, 12))).toBe("2026-11-09");
  });

  it("nový týden začíná v pondělí samostatně", () => {
    expect(mondayOfWeek(new Date(2026, 10, 16, 12))).toBe("2026-11-16");
  });
});
